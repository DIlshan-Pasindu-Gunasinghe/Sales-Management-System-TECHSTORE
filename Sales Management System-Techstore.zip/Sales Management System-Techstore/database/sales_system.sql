-- ============================================================================
-- Enterprise Sales Management System (EAD 1 Coursework)
-- Database Creation & Initial Data Seeding Script
-- Target DBMS: MySQL 8.0+
-- Database Name: ead_sales_db
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `ead_sales_db` 
    DEFAULT CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE `ead_sales_db`;

-- Disable foreign key checks for clean drop/create
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `users`;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------------
-- 1. Table: users
-- ----------------------------------------------------------------------------
CREATE TABLE `users` (
    `user_id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `role` ENUM('ADMIN', 'CASHIER', 'MANAGER') NOT NULL DEFAULT 'CASHIER',
    `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 2. Table: categories
-- ----------------------------------------------------------------------------
CREATE TABLE `categories` (
    `category_id` INT AUTO_INCREMENT PRIMARY KEY,
    `category_name` VARCHAR(100) NOT NULL UNIQUE,
    `description` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 3. Table: customers
-- ----------------------------------------------------------------------------
CREATE TABLE `customers` (
    `customer_id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_code` VARCHAR(30) NOT NULL UNIQUE,
    `name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `email` VARCHAR(100),
    `address` VARCHAR(255),
    `loyalty_points` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 4. Table: products
-- ----------------------------------------------------------------------------
CREATE TABLE `products` (
    `product_id` INT AUTO_INCREMENT PRIMARY KEY,
    `product_code` VARCHAR(30) NOT NULL UNIQUE,
    `product_name` VARCHAR(150) NOT NULL,
    `category_id` INT NOT NULL,
    `cost_price` DECIMAL(10,2) NOT NULL,
    `selling_price` DECIMAL(10,2) NOT NULL,
    `stock_quantity` INT NOT NULL DEFAULT 0,
    `reorder_level` INT NOT NULL DEFAULT 10,
    `barcode` VARCHAR(50),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) 
        REFERENCES `categories` (`category_id`) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 5. Table: orders
-- ----------------------------------------------------------------------------
CREATE TABLE `orders` (
    `order_id` INT AUTO_INCREMENT PRIMARY KEY,
    `invoice_no` VARCHAR(50) NOT NULL UNIQUE,
    `customer_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `order_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `subtotal` DECIMAL(12,2) NOT NULL,
    `discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `tax_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `grand_total` DECIMAL(12,2) NOT NULL,
    `payment_method` ENUM('CASH', 'CARD', 'ONLINE') NOT NULL DEFAULT 'CASH',
    `amount_paid` DECIMAL(12,2) NOT NULL,
    `balance_returned` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `status` ENUM('COMPLETED', 'CANCELLED') NOT NULL DEFAULT 'COMPLETED',
    `notes` TEXT,
    CONSTRAINT `fk_order_customer` FOREIGN KEY (`customer_id`) 
        REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) 
        REFERENCES `users` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 6. Table: order_items
-- ----------------------------------------------------------------------------
CREATE TABLE `order_items` (
    `order_item_id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `product_id` INT NOT NULL,
    `unit_cost_price` DECIMAL(10,2) NOT NULL,
    `unit_selling_price` DECIMAL(10,2) NOT NULL,
    `quantity` INT NOT NULL,
    `total_price` DECIMAL(12,2) NOT NULL,
    CONSTRAINT `fk_item_order` FOREIGN KEY (`order_id`) 
        REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_item_product` FOREIGN KEY (`product_id`) 
        REFERENCES `products` (`product_id`) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================================
-- SEED SAMPLE DATA
-- ============================================================================

-- Users (admin: admin123, cashier: cashier123, manager: manager123)
-- SHA-256 hashed or plain/digest verified
INSERT INTO `users` (`username`, `password`, `full_name`, `role`, `status`) VALUES
('admin', 'admin123', 'System Administrator', 'ADMIN', 'ACTIVE'),
('cashier', 'cashier123', 'Johnathan Perera', 'CASHIER', 'ACTIVE'),
('manager', 'manager123', 'Sarah Fernando', 'MANAGER', 'ACTIVE');

-- Categories
INSERT INTO `categories` (`category_name`, `description`) VALUES
('Laptops & Computers', 'High performance laptops, desktops, and workstation setups'),
('Computer Accessories', 'Mice, mechanical keyboards, webcams, and USB peripherals'),
('Displays & Monitors', 'Gaming, office, and ultra-wide high resolution display monitors'),
('Storage & Memory', 'NVMe SSDs, external hard drives, and DDR4/DDR5 RAM kits'),
('Networking', 'Dual-band Wi-Fi routers, network switches, and patch cords');

-- Customers
INSERT INTO `customers` (`customer_code`, `name`, `phone`, `email`, `address`, `loyalty_points`) VALUES
('CUST-001', 'Walk-in Customer', '0770000000', 'walkin@store.lk', 'Store Direct Counter', 0),
('CUST-002', 'Kasun Mendis', '0771234567', 'kasun.mendis@gmail.com', 'No 45, Galle Road, Colombo 03', 120),
('CUST-003', 'Dilshan Silva', '0719876543', 'dilshan.silva@yahoo.com', '128 Kandy Road, Kiribathgoda', 85),
('CUST-004', 'Apex Technologies Ltd', '0112345678', 'procurement@apextech.lk', 'Level 4, Orion City, Colombo 09', 450),
('CUST-005', 'Nimali Senanayake', '0765554321', 'nimali.sena@outlook.com', '82 Peradeniya Road, Kandy', 60);

-- Products
INSERT INTO `products` (`product_code`, `product_name`, `category_id`, `cost_price`, `selling_price`, `stock_quantity`, `reorder_level`, `barcode`) VALUES
('PROD-101', 'Dell Inspiron 15 Core i5', 1, 195000.00, 235000.00, 14, 5, '884116345671'),
('PROD-102', 'Lenovo ThinkPad E14 Gen 4', 1, 240000.00, 285000.00, 8, 4, '884116345672'),
('PROD-103', 'Logitech MX Master 3S Mouse', 2, 28000.00, 36500.00, 25, 8, '884116345673'),
('PROD-104', 'Keychron K2 Mechanical Keyboard', 2, 29000.00, 38000.00, 18, 6, '884116345674'),
('PROD-105', 'Samsung 27" Curved FHD Monitor', 3, 48000.00, 59500.00, 12, 5, '884116345675'),
('PROD-106', 'LG UltraWide 34" QHD Monitor', 3, 115000.00, 142000.00, 5, 3, '884116345676'),
('PROD-107', 'Samsung 980 Pro 1TB NVMe SSD', 4, 31000.00, 39500.00, 30, 10, '884116345677'),
('PROD-108', 'Corsair Vengeance 16GB DDR4 RAM', 4, 14000.00, 18500.00, 4, 8, '884116345678'), -- Low stock
('PROD-109', 'TP-Link Archer AX73 Wi-Fi 6 Router', 5, 34000.00, 43000.00, 15, 5, '884116345679'),
('PROD-110', 'Cat6 High-Speed RJ45 Patch Cord 5m', 5, 950.00, 1600.00, 2, 10, '884116345680'); -- Low stock

-- Past Sample Orders for Dashboard & Initial Jasper Reports
-- Order 1: Apex Technologies Ltd (CUST-004)
INSERT INTO `orders` (`invoice_no`, `customer_id`, `user_id`, `order_date`, `subtotal`, `discount_amount`, `tax_amount`, `grand_total`, `payment_method`, `amount_paid`, `balance_returned`, `status`, `notes`) VALUES
('INV-2026-0001', 4, 1, DATE_SUB(NOW(), INTERVAL 3 DAY), 590000.00, 20000.00, 10000.00, 580000.00, 'ONLINE', 580000.00, 0.00, 'COMPLETED', 'Corporate order - Office setup');

INSERT INTO `order_items` (`order_id`, `product_id`, `unit_cost_price`, `unit_selling_price`, `quantity`, `total_price`) VALUES
(1, 1, 195000.00, 235000.00, 2, 470000.00),
(1, 4, 29000.00, 38000.00, 2, 76000.00),
(1, 3, 28000.00, 36500.00, 1, 36500.00),
(1, 10, 950.00, 1600.00, 5, 8000.00);

-- Order 2: Kasun Mendis (CUST-002)
INSERT INTO `orders` (`invoice_no`, `customer_id`, `user_id`, `order_date`, `subtotal`, `discount_amount`, `tax_amount`, `grand_total`, `payment_method`, `amount_paid`, `balance_returned`, `status`, `notes`) VALUES
('INV-2026-0002', 2, 2, DATE_SUB(NOW(), INTERVAL 2 DAY), 96000.00, 1000.00, 0.00, 95000.00, 'CARD', 95000.00, 0.00, 'COMPLETED', 'Retail purchase');

INSERT INTO `order_items` (`order_id`, `product_id`, `unit_cost_price`, `unit_selling_price`, `quantity`, `total_price`) VALUES
(2, 5, 48000.00, 59500.00, 1, 59500.00),
(2, 3, 28000.00, 36500.00, 1, 36500.00);

-- Order 3: Dilshan Silva (CUST-003)
INSERT INTO `orders` (`invoice_no`, `customer_id`, `user_id`, `order_date`, `subtotal`, `discount_amount`, `tax_amount`, `grand_total`, `payment_method`, `amount_paid`, `balance_returned`, `status`, `notes`) VALUES
('INV-2026-0003', 3, 2, DATE_SUB(NOW(), INTERVAL 1 DAY), 58000.00, 0.00, 0.00, 58000.00, 'CASH', 60000.00, 2000.00, 'COMPLETED', 'Counter cash sale');

INSERT INTO `order_items` (`order_id`, `product_id`, `unit_cost_price`, `unit_selling_price`, `quantity`, `total_price`) VALUES
(3, 7, 31000.00, 39500.00, 1, 39500.00),
(3, 8, 14000.00, 18500.00, 1, 18500.00);

-- Order 4: Walk-in Customer (CUST-001) - Today
INSERT INTO `orders` (`invoice_no`, `customer_id`, `user_id`, `order_date`, `subtotal`, `discount_amount`, `tax_amount`, `grand_total`, `payment_method`, `amount_paid`, `balance_returned`, `status`, `notes`) VALUES
('INV-2026-0004', 1, 2, NOW(), 81000.00, 1000.00, 0.00, 80000.00, 'CASH', 80000.00, 0.00, 'COMPLETED', 'Cash Counter checkout');

INSERT INTO `order_items` (`order_id`, `product_id`, `unit_cost_price`, `unit_selling_price`, `quantity`, `total_price`) VALUES
(4, 4, 29000.00, 38000.00, 1, 38000.00),
(4, 9, 34000.00, 43000.00, 1, 43000.00);

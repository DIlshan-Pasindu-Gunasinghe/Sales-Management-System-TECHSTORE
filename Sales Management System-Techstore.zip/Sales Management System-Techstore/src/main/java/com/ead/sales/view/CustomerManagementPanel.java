package com.ead.sales.view;

import com.ead.sales.dao.CustomerDAO;
import com.ead.sales.dao.DAOFactory;
import com.ead.sales.model.Customer;
import com.ead.sales.service.ValidationService;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;
import com.ead.sales.util.ValidationException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * CustomerManagementPanel: Input UI for Customer Records & CRM
 * Supports customer registration, phone/email validation, loyalty points, and lookup.
 */
public class CustomerManagementPanel extends JPanel {

    private final CustomerDAO customerDAO = DAOFactory.getInstance().getCustomerDAO();

    private JTextField txtCode;
    private JTextField txtName;
    private JTextField txtPhone;
    private JTextField txtEmail;
    private JTextField txtAddress;
    private JTextField txtLoyalty;

    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;

    private JTextField txtSearch;
    private JTable tblCustomers;
    private DefaultTableModel modelCustomers;

    private int selectedCustomerId = -1;

    public CustomerManagementPanel() {
        initComponents();
        loadCustomers();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG_LIGHT);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // Top Header
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        JLabel lblTitle = new JLabel("Customer Management (CRM)");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_MAIN);
        topBar.add(lblTitle, BorderLayout.WEST);
        add(topBar, BorderLayout.NORTH);

        // Split Pane: Left Form (Input UI), Right Table
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.38);
        splitPane.setDividerSize(6);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);

        // LEFT: Form Card
        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.gridx = 0;

        // Title
        gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel lblFormTitle = new JLabel("Customer Profile Details");
        lblFormTitle.setFont(UITheme.FONT_SUBTITLE);
        lblFormTitle.setForeground(UITheme.TEXT_MAIN);
        formCard.add(lblFormTitle, gbc);

        gbc.gridwidth = 1;

        // Customer Code
        gbc.gridy = 1; gbc.gridx = 0;
        formCard.add(new JLabel("Customer Code:"), gbc);
        gbc.gridx = 1;
        txtCode = new JTextField(15);
        txtCode.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtCode, gbc);

        // Name
        gbc.gridy = 2; gbc.gridx = 0;
        formCard.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        txtName = new JTextField(15);
        txtName.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtName, gbc);

        // Phone
        gbc.gridy = 3; gbc.gridx = 0;
        formCard.add(new JLabel("Phone (07XXXXXXXX):"), gbc);
        gbc.gridx = 1;
        txtPhone = new JTextField(15);
        txtPhone.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtPhone, gbc);

        // Email
        gbc.gridy = 4; gbc.gridx = 0;
        formCard.add(new JLabel("Email Address:"), gbc);
        gbc.gridx = 1;
        txtEmail = new JTextField(15);
        txtEmail.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtEmail, gbc);

        // Address
        gbc.gridy = 5; gbc.gridx = 0;
        formCard.add(new JLabel("Billing Address:"), gbc);
        gbc.gridx = 1;
        txtAddress = new JTextField(15);
        txtAddress.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtAddress, gbc);

        // Loyalty Points
        gbc.gridy = 6; gbc.gridx = 0;
        formCard.add(new JLabel("Loyalty Points:"), gbc);
        gbc.gridx = 1;
        txtLoyalty = new JTextField("0", 15);
        txtLoyalty.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtLoyalty, gbc);

        // Buttons
        gbc.gridy = 7; gbc.gridx = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(16, 8, 4, 8);
        JPanel btnPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        btnPanel.setOpaque(false);

        btnAdd = UITheme.createPrimaryButton("+ Add Customer");
        btnUpdate = UITheme.createOutlineButton("Update");
        btnDelete = UITheme.createDangerButton("Delete");
        btnClear = UITheme.createOutlineButton("Clear");

        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);
        formCard.add(btnPanel, gbc);

        splitPane.setLeftComponent(formCard);

        // RIGHT: Customers Table Card
        JPanel tableCard = UITheme.createCardPanel();
        tableCard.setLayout(new BorderLayout(10, 10));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        filterPanel.setOpaque(false);
        filterPanel.add(new JLabel("Search by Name/Phone:"));
        txtSearch = new JTextField(18);
        filterPanel.add(txtSearch);

        JButton btnReload = UITheme.createOutlineButton("Refresh");
        btnReload.addActionListener(e -> loadCustomers());
        filterPanel.add(btnReload);

        tableCard.add(filterPanel, BorderLayout.NORTH);

        String[] cols = {"ID", "Code", "Name", "Phone", "Email", "Address", "Loyalty"};
        modelCustomers = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblCustomers = new JTable(modelCustomers);
        tblCustomers.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblCustomers, 0, SwingConstants.CENTER);
        alignTableColumn(tblCustomers, 1, SwingConstants.CENTER);
        alignTableColumn(tblCustomers, 6, SwingConstants.CENTER);

        tblCustomers.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tblCustomers.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableCard.add(new JScrollPane(tblCustomers), BorderLayout.CENTER);
        splitPane.setRightComponent(tableCard);

        add(splitPane, BorderLayout.CENTER);

        // Listeners
        btnAdd.addActionListener(e -> handleAddCustomer());
        btnUpdate.addActionListener(e -> handleUpdateCustomer());
        btnDelete.addActionListener(e -> handleDeleteCustomer());
        btnClear.addActionListener(e -> resetForm());

        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterCustomers(); }
            public void removeUpdate(DocumentEvent e) { filterCustomers(); }
            public void changedUpdate(DocumentEvent e) { filterCustomers(); }
        });
    }

    public void loadCustomers() {
        List<Customer> list = customerDAO.getAllCustomers();
        populateTable(list);
        resetForm();
    }

    private void populateTable(List<Customer> list) {
        modelCustomers.setRowCount(0);
        for (Customer c : list) {
            modelCustomers.addRow(new Object[]{
                    c.getCustomerId(),
                    c.getCustomerCode(),
                    c.getName(),
                    c.getPhone(),
                    c.getEmail(),
                    c.getAddress(),
                    c.getLoyaltyPoints()
            });
        }
    }

    private void filterCustomers() {
        String keyword = txtSearch.getText().trim();
        List<Customer> list = customerDAO.searchCustomers(keyword);
        populateTable(list);
    }

    private void populateFormFromSelectedRow() {
        int row = tblCustomers.getSelectedRow();
        if (row != -1) {
            selectedCustomerId = (int) modelCustomers.getValueAt(row, 0);
            Customer c = customerDAO.getCustomerById(selectedCustomerId);
            if (c != null) {
                txtCode.setText(c.getCustomerCode());
                txtName.setText(c.getName());
                txtPhone.setText(c.getPhone());
                txtEmail.setText(c.getEmail() != null ? c.getEmail() : "");
                txtAddress.setText(c.getAddress() != null ? c.getAddress() : "");
                txtLoyalty.setText(String.valueOf(c.getLoyaltyPoints()));

                btnAdd.setEnabled(false);
                btnUpdate.setEnabled(true);
                btnDelete.setEnabled(true);
            }
        }
    }

    private void handleAddCustomer() {
        try {
            Customer c = buildCustomerFromForm();
            if (c.getCustomerCode().isEmpty()) {
                c.setCustomerCode(customerDAO.generateNextCustomerCode());
            }

            if (customerDAO.addCustomer(c)) {
                ExceptionHandler.showSuccess(this, "Customer registered successfully!");
                loadCustomers();
            } else {
                ExceptionHandler.showError(this, "Failed to add customer. Ensure Customer Code is unique.");
            }
        } catch (ValidationException ex) {
            ExceptionHandler.showWarning(this, ex.getMessage());
        }
    }

    private void handleUpdateCustomer() {
        if (selectedCustomerId <= 0) return;
        try {
            Customer c = buildCustomerFromForm();
            c.setCustomerId(selectedCustomerId);

            if (customerDAO.updateCustomer(c)) {
                ExceptionHandler.showSuccess(this, "Customer updated successfully!");
                loadCustomers();
            } else {
                ExceptionHandler.showError(this, "Failed to update customer.");
            }
        } catch (ValidationException ex) {
            ExceptionHandler.showWarning(this, ex.getMessage());
        }
    }

    private void handleDeleteCustomer() {
        if (selectedCustomerId <= 0) return;
        if (ExceptionHandler.confirm(this, "Are you sure you want to delete this customer?")) {
            if (customerDAO.deleteCustomer(selectedCustomerId)) {
                ExceptionHandler.showSuccess(this, "Customer record deleted.");
                loadCustomers();
            } else {
                ExceptionHandler.showError(this, "Cannot delete customer! Existing sales invoices are linked to this customer.");
            }
        }
    }

    private Customer buildCustomerFromForm() throws ValidationException {
        String code = txtCode.getText().trim();
        String name = txtName.getText().trim();
        String phone = txtPhone.getText().trim();
        String email = txtEmail.getText().trim();
        String address = txtAddress.getText().trim();

        ValidationService.validateNotEmpty(name, "Customer Name");
        ValidationService.validateNotEmpty(phone, "Phone Number");
        ValidationService.validatePhone(phone);
        ValidationService.validateEmail(email);

        int loyalty = ValidationService.parsePositiveInt(txtLoyalty.getText(), "Loyalty Points");

        Customer c = new Customer();
        c.setCustomerCode(code);
        c.setName(name);
        c.setPhone(phone);
        c.setEmail(email);
        c.setAddress(address);
        c.setLoyaltyPoints(loyalty);
        return c;
    }

    private void resetForm() {
        selectedCustomerId = -1;
        txtCode.setText(customerDAO.generateNextCustomerCode());
        txtName.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        txtAddress.setText("");
        txtLoyalty.setText("0");
        tblCustomers.clearSelection();

        btnAdd.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void alignTableColumn(JTable table, int colIndex, int alignment) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(alignment);
        table.getColumnModel().getColumn(colIndex).setCellRenderer(renderer);
    }
}

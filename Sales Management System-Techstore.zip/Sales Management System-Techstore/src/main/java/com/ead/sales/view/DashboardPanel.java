package com.ead.sales.view;

import com.ead.sales.model.DashboardSummary;
import com.ead.sales.model.Order;
import com.ead.sales.model.Product;
import com.ead.sales.service.SalesService;
import com.ead.sales.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * DashboardPanel: Executive Management Overview
 * Real-time KPI summaries, recent transactions, inventory alerts, and quick actions.
 */
public class DashboardPanel extends JPanel {

    private final SalesService salesService = new SalesService();
    private final MainDashboardFrame parentFrame;

    private JLabel lblTodayRevenue;
    private JLabel lblMonthRevenue;
    private JLabel lblTotalProducts;
    private JLabel lblLowStock;

    private JTable tblRecentOrders;
    private DefaultTableModel modelRecentOrders;

    private JTable tblLowStock;
    private DefaultTableModel modelLowStock;

    private final NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(new Locale("en", "LK"));

    public DashboardPanel(MainDashboardFrame parentFrame) {
        this.parentFrame = parentFrame;
        initComponents();
        refreshData();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG_LIGHT);
        setBorder(new EmptyBorder(20, 25, 20, 25));

        // Top Header
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Executive Sales Dashboard");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_MAIN);

        JButton btnRefresh = UITheme.createOutlineButton("Refresh Live Metrics");
        btnRefresh.addActionListener(e -> refreshData());

        topPanel.add(lblTitle, BorderLayout.WEST);
        topPanel.add(btnRefresh, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // Center Content Scrollable or Split
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setOpaque(false);

        // 1. KPI Cards Row
        JPanel kpiGrid = new JPanel(new GridLayout(1, 4, 15, 0));
        kpiGrid.setOpaque(false);

        lblTodayRevenue = new JLabel("Rs. 0.00");
        lblMonthRevenue = new JLabel("Rs. 0.00");
        lblTotalProducts = new JLabel("0");
        lblLowStock = new JLabel("0");

        kpiGrid.add(createKpiCard("Today's Revenue", lblTodayRevenue, "Sales closed today", UITheme.PRIMARY));
        kpiGrid.add(createKpiCard("Monthly Sales", lblMonthRevenue, "Gross monthly volume", UITheme.SUCCESS));
        kpiGrid.add(createKpiCard("Total Inventory Items", lblTotalProducts, "Catalog active products", UITheme.PRIMARY_DARK));
        kpiGrid.add(createKpiCard("Low Stock Alerts", lblLowStock, "Requires urgent reordering", UITheme.DANGER));

        contentPanel.add(kpiGrid, BorderLayout.NORTH);

        // 2. Main Tables Area (Split between Recent Orders and Low Stock Alerts)
        JPanel tablesPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        tablesPanel.setOpaque(false);

        // Recent Orders Card
        JPanel cardOrders = UITheme.createCardPanel();
        cardOrders.setLayout(new BorderLayout(8, 8));

        JPanel ordersHeader = new JPanel(new BorderLayout());
        ordersHeader.setOpaque(false);
        JLabel lblOrdersTitle = new JLabel("Recent Sales Orders");
        lblOrdersTitle.setFont(UITheme.FONT_SUBTITLE);
        lblOrdersTitle.setForeground(UITheme.TEXT_MAIN);

        JButton btnViewAllOrders = UITheme.createOutlineButton("View All");
        btnViewAllOrders.setFont(UITheme.FONT_SMALL);
        btnViewAllOrders.addActionListener(e -> parentFrame.navigateTo("ORDERS"));

        ordersHeader.add(lblOrdersTitle, BorderLayout.WEST);
        ordersHeader.add(btnViewAllOrders, BorderLayout.EAST);
        cardOrders.add(ordersHeader, BorderLayout.NORTH);

        String[] orderCols = {"Invoice No", "Customer", "Date", "Total (LKR)", "Status"};
        modelRecentOrders = new DefaultTableModel(orderCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tblRecentOrders = new JTable(modelRecentOrders);
        tblRecentOrders.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblRecentOrders, 3, SwingConstants.RIGHT);
        alignTableColumn(tblRecentOrders, 4, SwingConstants.CENTER);

        JScrollPane scrollOrders = new JScrollPane(tblRecentOrders);
        scrollOrders.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));
        cardOrders.add(scrollOrders, BorderLayout.CENTER);

        // Low Stock Alerts Card
        JPanel cardStock = UITheme.createCardPanel();
        cardStock.setLayout(new BorderLayout(8, 8));

        JPanel stockHeader = new JPanel(new BorderLayout());
        stockHeader.setOpaque(false);
        JLabel lblStockTitle = new JLabel("Inventory Reorder Watchlist");
        lblStockTitle.setFont(UITheme.FONT_SUBTITLE);
        lblStockTitle.setForeground(UITheme.DANGER);

        JButton btnManageProducts = UITheme.createOutlineButton("Inventory");
        btnManageProducts.setFont(UITheme.FONT_SMALL);
        btnManageProducts.addActionListener(e -> parentFrame.navigateTo("PRODUCTS"));

        stockHeader.add(lblStockTitle, BorderLayout.WEST);
        stockHeader.add(btnManageProducts, BorderLayout.EAST);
        cardStock.add(stockHeader, BorderLayout.NORTH);

        String[] stockCols = {"Code", "Product Name", "Available", "Min Threshold"};
        modelLowStock = new DefaultTableModel(stockCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tblLowStock = new JTable(modelLowStock);
        tblLowStock.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblLowStock, 2, SwingConstants.CENTER);
        alignTableColumn(tblLowStock, 3, SwingConstants.CENTER);

        JScrollPane scrollStock = new JScrollPane(tblLowStock);
        scrollStock.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));
        cardStock.add(scrollStock, BorderLayout.CENTER);

        tablesPanel.add(cardOrders);
        tablesPanel.add(cardStock);

        contentPanel.add(tablesPanel, BorderLayout.CENTER);

        // 3. Quick Action Buttons Row
        JPanel quickActionsCard = UITheme.createCardPanel();
        quickActionsCard.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 8));

        JLabel lblQuick = new JLabel("Quick Actions: ");
        lblQuick.setFont(UITheme.FONT_BOLD);
        lblQuick.setForeground(UITheme.TEXT_MUTED);
        quickActionsCard.add(lblQuick);

        JButton btnNewSale = UITheme.createPrimaryButton("+ New Sale Transaction (POS)");
        btnNewSale.addActionListener(e -> parentFrame.navigateTo("TRANSACTION"));
        quickActionsCard.add(btnNewSale);

        JButton btnAddProduct = UITheme.createOutlineButton("+ Manage Products");
        btnAddProduct.addActionListener(e -> parentFrame.navigateTo("PRODUCTS"));
        quickActionsCard.add(btnAddProduct);

        JButton btnAddCust = UITheme.createOutlineButton("+ Manage Customers");
        btnAddCust.addActionListener(e -> parentFrame.navigateTo("CUSTOMERS"));
        quickActionsCard.add(btnAddCust);

        JButton btnReport = UITheme.createSuccessButton("Generate Decision Report");
        btnReport.addActionListener(e -> parentFrame.navigateTo("REPORTS"));
        quickActionsCard.add(btnReport);

        contentPanel.add(quickActionsCard, BorderLayout.SOUTH);

        add(contentPanel, BorderLayout.CENTER);
    }

    private JPanel createKpiCard(String title, JLabel valueLabel, String subtitle, Color accentColor) {
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new BorderLayout(5, 5));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accentColor),
                new EmptyBorder(12, 14, 12, 14)
        ));

        JLabel lblT = new JLabel(title);
        lblT.setFont(UITheme.FONT_BOLD);
        lblT.setForeground(UITheme.TEXT_MUTED);

        valueLabel.setFont(UITheme.FONT_KPI_NUMBER);
        valueLabel.setForeground(UITheme.TEXT_MAIN);

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(UITheme.FONT_SMALL);
        lblSub.setForeground(UITheme.TEXT_MUTED);

        card.add(lblT, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(lblSub, BorderLayout.SOUTH);

        return card;
    }

    public void refreshData() {
        SwingWorker<DashboardSummary, Void> worker = new SwingWorker<>() {
            @Override
            protected DashboardSummary doInBackground() {
                return salesService.getDashboardSummary();
            }

            @Override
            protected void done() {
                try {
                    DashboardSummary summary = get();
                    lblTodayRevenue.setText("Rs. " + formatAmount(summary.getTodayRevenue()));
                    lblMonthRevenue.setText("Rs. " + formatAmount(summary.getMonthRevenue()));
                    lblTotalProducts.setText(String.valueOf(summary.getTotalProducts()));
                    lblLowStock.setText(String.valueOf(summary.getLowStockCount()));

                    // Populate Recent Orders
                    modelRecentOrders.setRowCount(0);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                    for (Order o : summary.getRecentOrders()) {
                        modelRecentOrders.addRow(new Object[]{
                                o.getInvoiceNo(),
                                o.getCustomerName(),
                                o.getOrderDate() != null ? sdf.format(o.getOrderDate()) : "-",
                                "Rs. " + formatAmount(o.getGrandTotal()),
                                o.getStatus()
                        });
                    }

                    // Populate Low Stock
                    modelLowStock.setRowCount(0);
                    for (Product p : summary.getLowStockProducts()) {
                        modelLowStock.addRow(new Object[]{
                                p.getProductCode(),
                                p.getProductName(),
                                p.getStockQuantity(),
                                p.getReorderLevel()
                        });
                    }

                } catch (Exception ex) {
                    System.err.println("Error refreshing dashboard data: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private String formatAmount(BigDecimal amount) {
        if (amount == null) return "0.00";
        return String.format("%,.2f", amount);
    }

    private void alignTableColumn(JTable table, int colIndex, int alignment) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(alignment);
        table.getColumnModel().getColumn(colIndex).setCellRenderer(renderer);
    }
}

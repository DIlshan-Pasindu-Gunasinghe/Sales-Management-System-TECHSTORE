package com.ead.sales.dao;

/**
 * Factory Pattern: DAOFactory
 * Centralized factory for creating and providing DAO instances.
 * Promotes loose coupling and adheres to enterprise design patterns.
 */
public class DAOFactory {

    private static DAOFactory instance;

    private final UserDAO userDAO;
    private final CategoryDAO categoryDAO;
    private final CustomerDAO customerDAO;
    private final ProductDAO productDAO;
    private final OrderDAO orderDAO;

    private DAOFactory() {
        this.userDAO = new UserDAO();
        this.categoryDAO = new CategoryDAO();
        this.customerDAO = new CustomerDAO();
        this.productDAO = new ProductDAO();
        this.orderDAO = new OrderDAO();
    }

    public static synchronized DAOFactory getInstance() {
        if (instance == null) {
            instance = new DAOFactory();
        }
        return instance;
    }

    public UserDAO getUserDAO() {
        return userDAO;
    }

    public CategoryDAO getCategoryDAO() {
        return categoryDAO;
    }

    public CustomerDAO getCustomerDAO() {
        return customerDAO;
    }

    public ProductDAO getProductDAO() {
        return productDAO;
    }

    public OrderDAO getOrderDAO() {
        return orderDAO;
    }
}

package com.ead.sales;

import com.ead.sales.config.DBConnection;
import com.ead.sales.util.UITheme;
import com.ead.sales.view.LoginFrame;

import javax.swing.*;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Main Application Entry Point
 * National Institute of Business Management (NIBM)
 * Diploma in Software Engineering - Enterprise Application Development 1
 * Project: Enterprise Sales Management System
 */
public class Main {

    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        // 1. Initialize Modern FlatLaf Look & Feel
        UITheme.setupTheme();

        // 2. Pre-verify and initialize Database Connection in background
        new Thread(() -> {
            try {
                Connection conn = DBConnection.getInstance().getConnection();
                if (conn != null && !conn.isClosed()) {
                    LOGGER.info("MySQL connection established successfully.");
                }
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Initial database ping encountered issue: " + ex.getMessage());
            }
        }).start();

        // 3. Launch Login Window on Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            try {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Failed to start application UI", ex);
                JOptionPane.showMessageDialog(null, 
                        "Failed to launch application UI: " + ex.getMessage(), 
                        "Startup Error", 
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}

package com.ead.sales.view;

import com.ead.sales.dao.DAOFactory;
import com.ead.sales.model.Customer;
import com.ead.sales.model.Order;
import com.ead.sales.model.OrderItem;
import com.ead.sales.model.Product;
import com.ead.sales.model.User;
import com.ead.sales.service.ReportService;
import com.ead.sales.service.SalesService;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;
import com.ead.sales.util.ValidationException;
import net.sf.jasperreports.engine.JasperPrint;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * TransactionPanel: Major Transaction UI (POS Sales Terminal)
 * Manages itemized billing, real-time stock deduction, price calculations, 
 * payments, and Jasper receipt generation.
 */
public class TransactionPanel extends JPanel {

    private final User currentUser;
    private final SalesService salesService = new SalesService();

    // Data lists
    private List<Product> productCatalog = new ArrayList<>();
    private List<Customer> customerList = new ArrayList<>();
    private final List<OrderItem> currentCart = new ArrayList<>();

    // UI Components - Header & Customer
    private JLabel lblInvoiceNo;
    private JComboBox<Customer> cmbCustomer;
    private JButton btnNewCustomer;

    // Product Selection
    private JComboBox<Product> cmbProduct;
    private JTextField txtSearchProduct;
    private JLabel lblStockAvailable;
    private JLabel lblUnitPrice;
    private JSpinner spinQuantity;
    private JButton btnAddToCart;

    // Cart Table
    private JTable tblCart;
    private DefaultTableModel modelCart;
    private JButton btnRemoveItem;
    private JButton btnClearCart;

    // Totals & Checkout
    private JLabel lblSubtotal;
    private JTextField txtDiscount;
    private JLabel lblGrandTotal;
    private JComboBox<String> cmbPaymentMethod;
    private JTextField txtAmountPaid;
    private JLabel lblChangeReturned;
    private JTextArea txtNotes;
    private JButton btnCompleteSale;

    private BigDecimal currentSubtotal = BigDecimal.ZERO;
    private BigDecimal currentDiscount = BigDecimal.ZERO;
    private BigDecimal currentGrandTotal = BigDecimal.ZERO;
    private BigDecimal currentChange = BigDecimal.ZERO;

    public TransactionPanel(User user) {
        this.currentUser = user;
        initComponents();
        loadInitialData();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG_LIGHT);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // Top Bar: Invoice No, Cashier Name, and Date
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JLabel lblTitle = new JLabel("Sales Transaction Terminal (Point of Sale)");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_MAIN);

        lblInvoiceNo = new JLabel("Invoice #: INV-2026-XXXX");
        lblInvoiceNo.setFont(UITheme.FONT_SUBTITLE);
        lblInvoiceNo.setForeground(UITheme.PRIMARY);

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(lblInvoiceNo, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // Center Area: Left (Product selection & Cart Table), Right (Totals & Checkout)
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.68);
        splitPane.setDividerSize(6);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);

        // Left Panel (Product selection & Cart Table)
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setOpaque(false);

        // Customer Selection Bar
        JPanel customerCard = UITheme.createCardPanel();
        customerCard.setLayout(new GridBagLayout());
        GridBagConstraints gbcC = new GridBagConstraints();
        gbcC.fill = GridBagConstraints.HORIZONTAL;
        gbcC.insets = new Insets(4, 6, 4, 6);

        gbcC.gridx = 0; gbcC.gridy = 0;
        JLabel lblCust = new JLabel("Select Customer:");
        lblCust.setFont(UITheme.FONT_BOLD);
        customerCard.add(lblCust, gbcC);

        gbcC.gridx = 1; gbcC.weightx = 1.0;
        cmbCustomer = new JComboBox<>();
        cmbCustomer.setFont(UITheme.FONT_REGULAR);
        customerCard.add(cmbCustomer, gbcC);

        gbcC.gridx = 2; gbcC.weightx = 0;
        btnNewCustomer = UITheme.createOutlineButton("+ New Customer");
        btnNewCustomer.addActionListener(e -> quickAddCustomerDialog());
        customerCard.add(btnNewCustomer, gbcC);

        leftPanel.add(customerCard, BorderLayout.NORTH);

        // Product Selection & Cart Panel
        JPanel productCartCard = UITheme.createCardPanel();
        productCartCard.setLayout(new BorderLayout(10, 10));

        // Product Selector Header
        JPanel prodSelectPanel = new JPanel(new GridBagLayout());
        prodSelectPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 6, 4, 6);

        // Search Bar
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        JLabel lblSearch = new JLabel("Quick Search:");
        lblSearch.setFont(UITheme.FONT_BOLD);
        prodSelectPanel.add(lblSearch, gbc);

        gbc.gridx = 1; gbc.weightx = 0.5;
        txtSearchProduct = new JTextField();
        txtSearchProduct.setToolTipText("Filter by name, code, or barcode");
        prodSelectPanel.add(txtSearchProduct, gbc);

        // Product Dropdown
        gbc.gridx = 2; gbc.weightx = 0;
        JLabel lblProd = new JLabel("Select Item:");
        lblProd.setFont(UITheme.FONT_BOLD);
        prodSelectPanel.add(lblProd, gbc);

        gbc.gridx = 3; gbc.weightx = 0.5;
        cmbProduct = new JComboBox<>();
        cmbProduct.setFont(UITheme.FONT_REGULAR);
        prodSelectPanel.add(cmbProduct, gbc);

        // Details Row
        gbc.gridy = 1; gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblInfoP = new JLabel("Unit Price:");
        lblInfoP.setFont(UITheme.FONT_BOLD);
        prodSelectPanel.add(lblInfoP, gbc);

        gbc.gridx = 1;
        lblUnitPrice = new JLabel("Rs. 0.00");
        lblUnitPrice.setFont(UITheme.FONT_BOLD);
        lblUnitPrice.setForeground(UITheme.PRIMARY);
        prodSelectPanel.add(lblUnitPrice, gbc);

        gbc.gridx = 2;
        JLabel lblInfoS = new JLabel("Available Stock:");
        lblInfoS.setFont(UITheme.FONT_BOLD);
        prodSelectPanel.add(lblInfoS, gbc);

        gbc.gridx = 3;
        lblStockAvailable = new JLabel("0 units");
        lblStockAvailable.setFont(UITheme.FONT_BOLD);
        lblStockAvailable.setForeground(UITheme.SUCCESS);
        prodSelectPanel.add(lblStockAvailable, gbc);

        // Quantity & Add button row
        gbc.gridy = 2; gbc.gridx = 0;
        JLabel lblQty = new JLabel("Quantity:");
        lblQty.setFont(UITheme.FONT_BOLD);
        prodSelectPanel.add(lblQty, gbc);

        gbc.gridx = 1;
        spinQuantity = new JSpinner(new SpinnerNumberModel(1, 1, 9999, 1));
        spinQuantity.setFont(UITheme.FONT_REGULAR);
        prodSelectPanel.add(spinQuantity, gbc);

        gbc.gridx = 2; gbc.gridwidth = 2;
        btnAddToCart = UITheme.createPrimaryButton("+ Add Item to Bill");
        btnAddToCart.addActionListener(e -> addItemToCart());
        prodSelectPanel.add(btnAddToCart, gbc);

        productCartCard.add(prodSelectPanel, BorderLayout.NORTH);

        // Cart Table
        String[] cartCols = {"#", "Product Code", "Description", "Unit Price (Rs)", "Qty", "Total (Rs)"};
        modelCart = new DefaultTableModel(cartCols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblCart = new JTable(modelCart);
        tblCart.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblCart, 0, SwingConstants.CENTER);
        alignTableColumn(tblCart, 3, SwingConstants.RIGHT);
        alignTableColumn(tblCart, 4, SwingConstants.CENTER);
        alignTableColumn(tblCart, 5, SwingConstants.RIGHT);

        JScrollPane scrollCart = new JScrollPane(tblCart);
        scrollCart.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));
        productCartCard.add(scrollCart, BorderLayout.CENTER);

        // Cart Actions Footer
        JPanel cartFooter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        cartFooter.setOpaque(false);
        btnRemoveItem = UITheme.createDangerButton("Remove Selected Item");
        btnRemoveItem.addActionListener(e -> removeSelectedItem());
        btnClearCart = UITheme.createOutlineButton("Clear Cart");
        btnClearCart.addActionListener(e -> clearCart());

        cartFooter.add(btnClearCart);
        cartFooter.add(btnRemoveItem);
        productCartCard.add(cartFooter, BorderLayout.SOUTH);

        leftPanel.add(productCartCard, BorderLayout.CENTER);
        splitPane.setLeftComponent(leftPanel);

        // Right Panel: Financial Checkout Card
        JPanel checkoutCard = UITheme.createCardPanel();
        checkoutCard.setLayout(new GridBagLayout());
        GridBagConstraints gbcR = new GridBagConstraints();
        gbcR.fill = GridBagConstraints.HORIZONTAL;
        gbcR.insets = new Insets(8, 10, 8, 10);
        gbcR.gridx = 0;

        // Title
        gbcR.gridy = 0;
        JLabel lblCheckTitle = new JLabel("Payment & Checkout");
        lblCheckTitle.setFont(UITheme.FONT_SUBTITLE);
        lblCheckTitle.setForeground(UITheme.TEXT_MAIN);
        checkoutCard.add(lblCheckTitle, gbcR);

        // Subtotal
        gbcR.gridy = 1;
        JLabel lblSubT = new JLabel("Subtotal Amount:");
        lblSubT.setFont(UITheme.FONT_BOLD);
        checkoutCard.add(lblSubT, gbcR);

        gbcR.gridy = 2;
        lblSubtotal = new JLabel("Rs. 0.00");
        lblSubtotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblSubtotal.setForeground(UITheme.TEXT_MAIN);
        checkoutCard.add(lblSubtotal, gbcR);

        // Discount
        gbcR.gridy = 3;
        JLabel lblDisc = new JLabel("Discount (Rs):");
        lblDisc.setFont(UITheme.FONT_BOLD);
        checkoutCard.add(lblDisc, gbcR);

        gbcR.gridy = 4;
        txtDiscount = new JTextField("0.00");
        txtDiscount.setFont(UITheme.FONT_REGULAR);
        checkoutCard.add(txtDiscount, gbcR);

        // Grand Total Display
        gbcR.gridy = 5;
        JPanel totalBox = new JPanel(new BorderLayout(5, 5));
        totalBox.setBackground(UITheme.PRIMARY_LIGHT);
        totalBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.PRIMARY, 1, true),
                new EmptyBorder(10, 12, 10, 12)
        ));
        JLabel lblTotalT = new JLabel("NET GRAND TOTAL:");
        lblTotalT.setFont(UITheme.FONT_BOLD);
        lblTotalT.setForeground(UITheme.PRIMARY_DARK);

        lblGrandTotal = new JLabel("Rs. 0.00");
        lblGrandTotal.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblGrandTotal.setForeground(UITheme.PRIMARY);

        totalBox.add(lblTotalT, BorderLayout.NORTH);
        totalBox.add(lblGrandTotal, BorderLayout.CENTER);
        checkoutCard.add(totalBox, gbcR);

        // Payment Method
        gbcR.gridy = 6;
        JLabel lblPayM = new JLabel("Payment Method:");
        lblPayM.setFont(UITheme.FONT_BOLD);
        checkoutCard.add(lblPayM, gbcR);

        gbcR.gridy = 7;
        cmbPaymentMethod = new JComboBox<>(new String[]{"CASH", "CARD", "ONLINE"});
        cmbPaymentMethod.setFont(UITheme.FONT_REGULAR);
        checkoutCard.add(cmbPaymentMethod, gbcR);

        // Amount Paid
        gbcR.gridy = 8;
        JLabel lblPaid = new JLabel("Amount Tendered (Rs):");
        lblPaid.setFont(UITheme.FONT_BOLD);
        checkoutCard.add(lblPaid, gbcR);

        gbcR.gridy = 9;
        txtAmountPaid = new JTextField();
        txtAmountPaid.setFont(new Font("Segoe UI", Font.BOLD, 16));
        checkoutCard.add(txtAmountPaid, gbcR);

        // Change Returned
        gbcR.gridy = 10;
        JLabel lblChangeT = new JLabel("Balance / Change:");
        lblChangeT.setFont(UITheme.FONT_BOLD);
        checkoutCard.add(lblChangeT, gbcR);

        gbcR.gridy = 11;
        lblChangeReturned = new JLabel("Rs. 0.00");
        lblChangeReturned.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblChangeReturned.setForeground(UITheme.SUCCESS);
        checkoutCard.add(lblChangeReturned, gbcR);

        // Notes
        gbcR.gridy = 12;
        JLabel lblNotesT = new JLabel("Transaction Notes / Remarks:");
        lblNotesT.setFont(UITheme.FONT_SMALL);
        checkoutCard.add(lblNotesT, gbcR);

        gbcR.gridy = 13;
        txtNotes = new JTextArea(2, 20);
        txtNotes.setFont(UITheme.FONT_REGULAR);
        txtNotes.setLineWrap(true);
        checkoutCard.add(new JScrollPane(txtNotes), gbcR);

        // Complete Checkout Button
        gbcR.gridy = 14;
        gbcR.insets = new Insets(14, 10, 5, 10);
        btnCompleteSale = UITheme.createSuccessButton("COMPLETE SALE & PRINT RECEIPT");
        btnCompleteSale.setPreferredSize(new Dimension(220, 44));
        btnCompleteSale.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCompleteSale.addActionListener(e -> processCheckout());
        checkoutCard.add(btnCompleteSale, gbcR);

        splitPane.setRightComponent(checkoutCard);
        add(splitPane, BorderLayout.CENTER);

        // Listeners for live recalculation
        cmbProduct.addActionListener(e -> onProductSelected());

        txtSearchProduct.getDocument().addDocumentListener(new SimpleDocumentListener(this::filterProducts));

        txtDiscount.getDocument().addDocumentListener(new SimpleDocumentListener(this::recalculateFinancials));

        txtAmountPaid.getDocument().addDocumentListener(new SimpleDocumentListener(this::recalculateFinancials));
    }

    public void loadInitialData() {
        lblInvoiceNo.setText("Invoice #: " + salesService.generateNextInvoiceNo());

        // Load Customers
        customerList = DAOFactory.getInstance().getCustomerDAO().getAllCustomers();
        cmbCustomer.removeAllItems();
        for (Customer c : customerList) {
            cmbCustomer.addItem(c);
        }

        // Load Products
        productCatalog = DAOFactory.getInstance().getProductDAO().getAllProducts();
        populateProductDropdown(productCatalog);
    }

    private void populateProductDropdown(List<Product> products) {
        cmbProduct.removeAllItems();
        for (Product p : products) {
            cmbProduct.addItem(p);
        }
        if (!products.isEmpty()) {
            cmbProduct.setSelectedIndex(0);
            onProductSelected();
        }
    }

    private void filterProducts() {
        String keyword = txtSearchProduct.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            populateProductDropdown(productCatalog);
            return;
        }
        List<Product> filtered = new ArrayList<>();
        for (Product p : productCatalog) {
            if (p.getProductName().toLowerCase().contains(keyword) ||
                p.getProductCode().toLowerCase().contains(keyword) ||
                (p.getBarcode() != null && p.getBarcode().toLowerCase().contains(keyword))) {
                filtered.add(p);
            }
        }
        populateProductDropdown(filtered);
    }

    private void onProductSelected() {
        Product selected = (Product) cmbProduct.getSelectedItem();
        if (selected != null) {
            lblUnitPrice.setText("Rs. " + String.format("%,.2f", selected.getSellingPrice()));
            lblStockAvailable.setText(selected.getStockQuantity() + " units in stock");
            if (selected.isLowStock()) {
                lblStockAvailable.setForeground(UITheme.DANGER);
            } else {
                lblStockAvailable.setForeground(UITheme.SUCCESS);
            }
        } else {
            lblUnitPrice.setText("Rs. 0.00");
            lblStockAvailable.setText("0 units");
        }
    }

    private void addItemToCart() {
        Product selected = (Product) cmbProduct.getSelectedItem();
        if (selected == null) {
            ExceptionHandler.showWarning(this, "Please select a product to add.");
            return;
        }

        int requestedQty = (Integer) spinQuantity.getValue();
        if (requestedQty <= 0) {
            ExceptionHandler.showWarning(this, "Quantity must be greater than zero.");
            return;
        }

        // Calculate already added quantity for this product
        int alreadyInCart = 0;
        for (OrderItem item : currentCart) {
            if (item.getProductId() == selected.getProductId()) {
                alreadyInCart += item.getQuantity();
            }
        }

        if (alreadyInCart + requestedQty > selected.getStockQuantity()) {
            ExceptionHandler.showWarning(this, "Insufficient stock! Available: " 
                    + selected.getStockQuantity() + ", Already in cart: " + alreadyInCart);
            return;
        }

        // Check if item already exists in cart, then increment quantity
        boolean existingFound = false;
        for (OrderItem item : currentCart) {
            if (item.getProductId() == selected.getProductId()) {
                item.setQuantity(item.getQuantity() + requestedQty);
                existingFound = true;
                break;
            }
        }

        if (!existingFound) {
            OrderItem newItem = new OrderItem(
                    selected.getProductId(),
                    selected.getProductCode(),
                    selected.getProductName(),
                    selected.getCostPrice(),
                    selected.getSellingPrice(),
                    requestedQty
            );
            currentCart.add(newItem);
        }

        refreshCartTable();
        spinQuantity.setValue(1);
    }

    private void removeSelectedItem() {
        int selectedRow = tblCart.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < currentCart.size()) {
            currentCart.remove(selectedRow);
            refreshCartTable();
        } else {
            ExceptionHandler.showWarning(this, "Please select an item from the cart to remove.");
        }
    }

    private void clearCart() {
        if (!currentCart.isEmpty()) {
            if (ExceptionHandler.confirm(this, "Are you sure you want to clear the entire cart?")) {
                currentCart.clear();
                refreshCartTable();
            }
        }
    }

    private void refreshCartTable() {
        modelCart.setRowCount(0);
        int index = 1;
        currentSubtotal = BigDecimal.ZERO;

        for (OrderItem item : currentCart) {
            modelCart.addRow(new Object[]{
                    index++,
                    item.getProductCode(),
                    item.getProductName(),
                    String.format("%,.2f", item.getUnitSellingPrice()),
                    item.getQuantity(),
                    String.format("%,.2f", item.getTotalPrice())
            });
            currentSubtotal = currentSubtotal.add(item.getTotalPrice());
        }

        lblSubtotal.setText("Rs. " + String.format("%,.2f", currentSubtotal));
        recalculateFinancials();
    }

    private void recalculateFinancials() {
        // Parse discount
        try {
            String discText = txtDiscount.getText().trim();
            currentDiscount = discText.isEmpty() ? BigDecimal.ZERO : new BigDecimal(discText);
            if (currentDiscount.compareTo(BigDecimal.ZERO) < 0) currentDiscount = BigDecimal.ZERO;
        } catch (NumberFormatException e) {
            currentDiscount = BigDecimal.ZERO;
        }

        currentGrandTotal = currentSubtotal.subtract(currentDiscount);
        if (currentGrandTotal.compareTo(BigDecimal.ZERO) < 0) {
            currentGrandTotal = BigDecimal.ZERO;
        }

        lblGrandTotal.setText("Rs. " + String.format("%,.2f", currentGrandTotal));

        // Parse amount paid
        try {
            String paidText = txtAmountPaid.getText().trim();
            BigDecimal amountPaid = paidText.isEmpty() ? BigDecimal.ZERO : new BigDecimal(paidText);
            if (amountPaid.compareTo(currentGrandTotal) >= 0) {
                currentChange = amountPaid.subtract(currentGrandTotal);
                lblChangeReturned.setText("Rs. " + String.format("%,.2f", currentChange));
                lblChangeReturned.setForeground(UITheme.SUCCESS);
            } else {
                currentChange = BigDecimal.ZERO;
                BigDecimal shortage = currentGrandTotal.subtract(amountPaid);
                lblChangeReturned.setText("Short: Rs. " + String.format("%,.2f", shortage));
                lblChangeReturned.setForeground(UITheme.DANGER);
            }
        } catch (NumberFormatException e) {
            lblChangeReturned.setText("Rs. 0.00");
        }
    }

    private void processCheckout() {
        if (currentCart.isEmpty()) {
            ExceptionHandler.showWarning(this, "Cart is empty! Please add products before checking out.");
            return;
        }

        Customer customer = (Customer) cmbCustomer.getSelectedItem();
        if (customer == null) {
            ExceptionHandler.showWarning(this, "Please select a customer.");
            return;
        }

        BigDecimal amountPaid;
        try {
            String paidText = txtAmountPaid.getText().trim();
            if (paidText.isEmpty()) {
                ExceptionHandler.showWarning(this, "Please enter the amount paid.");
                return;
            }
            amountPaid = new BigDecimal(paidText);
            if (amountPaid.compareTo(currentGrandTotal) < 0) {
                ExceptionHandler.showError(this, "Insufficient payment tendered! Minimum required: Rs. " 
                        + String.format("%,.2f", currentGrandTotal));
                return;
            }
        } catch (NumberFormatException ex) {
            ExceptionHandler.showError(this, "Please enter a valid numeric payment amount.");
            return;
        }

        try {
            Order order = new Order();
            order.setInvoiceNo(salesService.generateNextInvoiceNo());
            order.setCustomerId(customer.getCustomerId());
            order.setUserId(currentUser.getUserId());
            order.setSubtotal(currentSubtotal);
            order.setDiscountAmount(currentDiscount);
            order.setTaxAmount(BigDecimal.ZERO);
            order.setGrandTotal(currentGrandTotal);
            order.setPaymentMethod((String) cmbPaymentMethod.getSelectedItem());
            order.setAmountPaid(amountPaid);
            order.setBalanceReturned(currentChange);
            order.setStatus("COMPLETED");
            order.setNotes(txtNotes.getText().trim());

            for (OrderItem item : currentCart) {
                order.addItem(item);
            }

            boolean success = salesService.completeSale(order);
            if (success) {
                ExceptionHandler.showSuccess(this, "Transaction completed successfully!\nInvoice: " + order.getInvoiceNo());

                // Offer Jasper Receipt generation
                if (ExceptionHandler.confirm(this, "Do you want to preview & print the Jasper customer receipt?")) {
                    try {
                        JasperPrint print = ReportService.getInstance().generateReceipt(order.getOrderId());
                        ReportService.getInstance().viewReport(print, "Customer Receipt - " + order.getInvoiceNo());
                    } catch (Exception rEx) {
                        ExceptionHandler.showError(this, "Could not launch Jasper receipt: " + rEx.getMessage());
                    }
                }

                // Reset form
                currentCart.clear();
                refreshCartTable();
                txtDiscount.setText("0.00");
                txtAmountPaid.setText("");
                txtNotes.setText("");
                loadInitialData(); // Refreshes products catalog and next invoice number
            }

        } catch (ValidationException vEx) {
            ExceptionHandler.showWarning(this, vEx.getMessage());
        } catch (Exception ex) {
            ExceptionHandler.showError(this, "Transaction failed: " + ex.getMessage());
        }
    }

    private void quickAddCustomerDialog() {
        JTextField nameField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField emailField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Full Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Phone Number (e.g. 0771234567):"));
        panel.add(phoneField);
        panel.add(new JLabel("Email (optional):"));
        panel.add(emailField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Quick Add Customer", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            if (name.isEmpty() || phone.isEmpty()) {
                ExceptionHandler.showWarning(this, "Customer name and phone number are required.");
                return;
            }

            Customer c = new Customer();
            c.setCustomerCode(DAOFactory.getInstance().getCustomerDAO().generateNextCustomerCode());
            c.setName(name);
            c.setPhone(phone);
            c.setEmail(emailField.getText().trim());
            c.setAddress("Store Customer");
            c.setLoyaltyPoints(10);

            if (DAOFactory.getInstance().getCustomerDAO().addCustomer(c)) {
                ExceptionHandler.showSuccess(this, "Customer registered successfully!");
                loadInitialData();
                cmbCustomer.setSelectedItem(c);
            } else {
                ExceptionHandler.showError(this, "Could not add customer.");
            }
        }
    }

    private void alignTableColumn(JTable table, int colIndex, int alignment) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(alignment);
        table.getColumnModel().getColumn(colIndex).setCellRenderer(renderer);
    }

    private static class SimpleDocumentListener implements DocumentListener {
        private final Runnable action;
        public SimpleDocumentListener(Runnable action) { this.action = action; }
        public void insertUpdate(DocumentEvent e) { action.run(); }
        public void removeUpdate(DocumentEvent e) { action.run(); }
        public void changedUpdate(DocumentEvent e) { action.run(); }
    }
}

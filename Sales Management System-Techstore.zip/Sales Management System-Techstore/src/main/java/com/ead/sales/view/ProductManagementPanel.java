package com.ead.sales.view;

import com.ead.sales.dao.CategoryDAO;
import com.ead.sales.dao.DAOFactory;
import com.ead.sales.dao.ProductDAO;
import com.ead.sales.model.Category;
import com.ead.sales.model.Product;
import com.ead.sales.service.ValidationService;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;
import com.ead.sales.util.ValidationException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * ProductManagementPanel: Input UI for Catalog & Stock Inventory
 * Allows Adding, Updating, Deleting, and Searching products.
 */
public class ProductManagementPanel extends JPanel {

    private final ProductDAO productDAO = DAOFactory.getInstance().getProductDAO();
    private final CategoryDAO categoryDAO = DAOFactory.getInstance().getCategoryDAO();

    private JTextField txtCode;
    private JTextField txtName;
    private JComboBox<Category> cmbCategory;
    private JTextField txtCostPrice;
    private JTextField txtSellingPrice;
    private JTextField txtStockQty;
    private JTextField txtReorderLevel;
    private JTextField txtBarcode;

    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;

    private JTextField txtSearch;
    private JComboBox<String> cmbCategoryFilter;
    private JTable tblProducts;
    private DefaultTableModel modelProducts;

    private int selectedProductId = -1;

    public ProductManagementPanel() {
        initComponents();
        loadCategories();
        loadProducts();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG_LIGHT);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // Top Header
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        JLabel lblTitle = new JLabel("Product & Inventory Management");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_MAIN);
        topBar.add(lblTitle, BorderLayout.WEST);
        add(topBar, BorderLayout.NORTH);

        // Split Pane: Left Form (Input UI), Right Table
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.38);
        splitPane.setDividerSize(6);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);

        // LEFT: Input Form Card
        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.gridx = 0;

        // Form Title
        gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel lblFormTitle = new JLabel("Product Information Details");
        lblFormTitle.setFont(UITheme.FONT_SUBTITLE);
        lblFormTitle.setForeground(UITheme.TEXT_MAIN);
        formCard.add(lblFormTitle, gbc);

        gbc.gridwidth = 1;

        // Code
        gbc.gridy = 1; gbc.gridx = 0;
        formCard.add(new JLabel("Product Code:"), gbc);
        gbc.gridx = 1;
        txtCode = new JTextField(15);
        txtCode.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtCode, gbc);

        // Name
        gbc.gridy = 2; gbc.gridx = 0;
        formCard.add(new JLabel("Product Name:"), gbc);
        gbc.gridx = 1;
        txtName = new JTextField(15);
        txtName.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtName, gbc);

        // Category
        gbc.gridy = 3; gbc.gridx = 0;
        formCard.add(new JLabel("Category:"), gbc);
        gbc.gridx = 1;
        cmbCategory = new JComboBox<>();
        cmbCategory.setFont(UITheme.FONT_REGULAR);
        formCard.add(cmbCategory, gbc);

        // Cost Price
        gbc.gridy = 4; gbc.gridx = 0;
        formCard.add(new JLabel("Cost Price (LKR):"), gbc);
        gbc.gridx = 1;
        txtCostPrice = new JTextField(15);
        txtCostPrice.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtCostPrice, gbc);

        // Selling Price
        gbc.gridy = 5; gbc.gridx = 0;
        formCard.add(new JLabel("Selling Price (LKR):"), gbc);
        gbc.gridx = 1;
        txtSellingPrice = new JTextField(15);
        txtSellingPrice.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtSellingPrice, gbc);

        // Stock Quantity
        gbc.gridy = 6; gbc.gridx = 0;
        formCard.add(new JLabel("Current Stock:"), gbc);
        gbc.gridx = 1;
        txtStockQty = new JTextField(15);
        txtStockQty.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtStockQty, gbc);

        // Reorder Level
        gbc.gridy = 7; gbc.gridx = 0;
        formCard.add(new JLabel("Min Reorder Level:"), gbc);
        gbc.gridx = 1;
        txtReorderLevel = new JTextField("10", 15);
        txtReorderLevel.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtReorderLevel, gbc);

        // Barcode
        gbc.gridy = 8; gbc.gridx = 0;
        formCard.add(new JLabel("Barcode / SKU:"), gbc);
        gbc.gridx = 1;
        txtBarcode = new JTextField(15);
        txtBarcode.setFont(UITheme.FONT_REGULAR);
        formCard.add(txtBarcode, gbc);

        // Action Buttons Row
        gbc.gridy = 9; gbc.gridx = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(14, 8, 4, 8);
        JPanel btnPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        btnPanel.setOpaque(false);

        btnAdd = UITheme.createPrimaryButton("+ Add New");
        btnUpdate = UITheme.createOutlineButton("Update");
        btnDelete = UITheme.createDangerButton("Delete");
        btnClear = UITheme.createOutlineButton("Clear Form");

        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);
        formCard.add(btnPanel, gbc);

        splitPane.setLeftComponent(formCard);

        // RIGHT: Data Table Card
        JPanel tableCard = UITheme.createCardPanel();
        tableCard.setLayout(new BorderLayout(10, 10));

        // Search Bar Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        filterPanel.setOpaque(false);

        filterPanel.add(new JLabel("Search Products:"));
        txtSearch = new JTextField(18);
        filterPanel.add(txtSearch);

        JButton btnReload = UITheme.createOutlineButton("Refresh");
        btnReload.addActionListener(e -> loadProducts());
        filterPanel.add(btnReload);

        tableCard.add(filterPanel, BorderLayout.NORTH);

        String[] cols = {"ID", "Code", "Name", "Category", "Cost Price", "Sell Price", "Stock", "Reorder", "Status"};
        modelProducts = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblProducts = new JTable(modelProducts);
        tblProducts.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblProducts, 0, SwingConstants.CENTER);
        alignTableColumn(tblProducts, 4, SwingConstants.RIGHT);
        alignTableColumn(tblProducts, 5, SwingConstants.RIGHT);
        alignTableColumn(tblProducts, 6, SwingConstants.CENTER);
        alignTableColumn(tblProducts, 7, SwingConstants.CENTER);
        alignTableColumn(tblProducts, 8, SwingConstants.CENTER);

        // Selection Listener
        tblProducts.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tblProducts.getSelectedRow() != -1) {
                populateFormFromSelectedRow();
            }
        });

        tableCard.add(new JScrollPane(tblProducts), BorderLayout.CENTER);
        splitPane.setRightComponent(tableCard);

        add(splitPane, BorderLayout.CENTER);

        // Events
        btnAdd.addActionListener(e -> handleAddProduct());
        btnUpdate.addActionListener(e -> handleUpdateProduct());
        btnDelete.addActionListener(e -> handleDeleteProduct());
        btnClear.addActionListener(e -> resetForm());

        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterTable(); }
            public void removeUpdate(DocumentEvent e) { filterTable(); }
            public void changedUpdate(DocumentEvent e) { filterTable(); }
        });
    }

    private void loadCategories() {
        List<Category> categories = categoryDAO.getAllCategories();
        cmbCategory.removeAllItems();
        for (Category c : categories) {
            cmbCategory.addItem(c);
        }
    }

    public void loadProducts() {
        List<Product> list = productDAO.getAllProducts();
        populateTable(list);
        resetForm();
    }

    private void populateTable(List<Product> list) {
        modelProducts.setRowCount(0);
        for (Product p : list) {
            String status = p.isLowStock() ? "LOW STOCK" : "In Stock";
            modelProducts.addRow(new Object[]{
                    p.getProductId(),
                    p.getProductCode(),
                    p.getProductName(),
                    p.getCategoryName(),
                    String.format("%,.2f", p.getCostPrice()),
                    String.format("%,.2f", p.getSellingPrice()),
                    p.getStockQuantity(),
                    p.getReorderLevel(),
                    status
            });
        }
    }

    private void filterTable() {
        String keyword = txtSearch.getText().trim();
        List<Product> list = productDAO.searchProducts(keyword, null);
        populateTable(list);
    }

    private void populateFormFromSelectedRow() {
        int row = tblProducts.getSelectedRow();
        if (row != -1) {
            selectedProductId = (int) modelProducts.getValueAt(row, 0);
            Product p = productDAO.getProductById(selectedProductId);
            if (p != null) {
                txtCode.setText(p.getProductCode());
                txtName.setText(p.getProductName());
                txtCostPrice.setText(p.getCostPrice().toPlainString());
                txtSellingPrice.setText(p.getSellingPrice().toPlainString());
                txtStockQty.setText(String.valueOf(p.getStockQuantity()));
                txtReorderLevel.setText(String.valueOf(p.getReorderLevel()));
                txtBarcode.setText(p.getBarcode() != null ? p.getBarcode() : "");

                for (int i = 0; i < cmbCategory.getItemCount(); i++) {
                    if (cmbCategory.getItemAt(i).getCategoryId() == p.getCategoryId()) {
                        cmbCategory.setSelectedIndex(i);
                        break;
                    }
                }

                btnAdd.setEnabled(false);
                btnUpdate.setEnabled(true);
                btnDelete.setEnabled(true);
            }
        }
    }

    private void handleAddProduct() {
        try {
            Product p = buildProductFromForm();
            if (p.getProductCode().isEmpty()) {
                p.setProductCode(productDAO.generateNextProductCode());
            }

            if (productDAO.addProduct(p)) {
                ExceptionHandler.showSuccess(this, "Product added successfully: " + p.getProductName());
                loadProducts();
            } else {
                ExceptionHandler.showError(this, "Failed to add product. Ensure Product Code is unique.");
            }
        } catch (ValidationException ex) {
            ExceptionHandler.showWarning(this, ex.getMessage());
        }
    }

    private void handleUpdateProduct() {
        if (selectedProductId <= 0) return;
        try {
            Product p = buildProductFromForm();
            p.setProductId(selectedProductId);

            if (productDAO.updateProduct(p)) {
                ExceptionHandler.showSuccess(this, "Product updated successfully!");
                loadProducts();
            } else {
                ExceptionHandler.showError(this, "Failed to update product.");
            }
        } catch (ValidationException ex) {
            ExceptionHandler.showWarning(this, ex.getMessage());
        }
    }

    private void handleDeleteProduct() {
        if (selectedProductId <= 0) return;
        if (ExceptionHandler.confirm(this, "Are you sure you want to delete this product?")) {
            if (productDAO.deleteProduct(selectedProductId)) {
                ExceptionHandler.showSuccess(this, "Product deleted successfully.");
                loadProducts();
            } else {
                ExceptionHandler.showError(this, "Cannot delete product! It may be referenced in existing sales orders.");
            }
        }
    }

    private Product buildProductFromForm() throws ValidationException {
        String code = txtCode.getText().trim();
        String name = txtName.getText().trim();
        ValidationService.validateNotEmpty(name, "Product Name");

        Category cat = (Category) cmbCategory.getSelectedItem();
        if (cat == null) {
            throw new ValidationException("Please select a category.");
        }

        BigDecimal cost = ValidationService.parsePositiveDecimal(txtCostPrice.getText(), "Cost Price");
        BigDecimal sell = ValidationService.parsePositiveDecimal(txtSellingPrice.getText(), "Selling Price");
        int stock = ValidationService.parsePositiveInt(txtStockQty.getText(), "Stock Quantity");
        int reorder = ValidationService.parsePositiveInt(txtReorderLevel.getText(), "Reorder Level");
        String barcode = txtBarcode.getText().trim();

        if (sell.compareTo(cost) < 0) {
            throw new ValidationException("Selling price should not be lower than Cost price!");
        }

        Product p = new Product();
        p.setProductCode(code);
        p.setProductName(name);
        p.setCategoryId(cat.getCategoryId());
        p.setCostPrice(cost);
        p.setSellingPrice(sell);
        p.setStockQuantity(stock);
        p.setReorderLevel(reorder);
        p.setBarcode(barcode);
        return p;
    }

    private void resetForm() {
        selectedProductId = -1;
        txtCode.setText(productDAO.generateNextProductCode());
        txtName.setText("");
        txtCostPrice.setText("");
        txtSellingPrice.setText("");
        txtStockQty.setText("");
        txtReorderLevel.setText("10");
        txtBarcode.setText("");
        tblProducts.clearSelection();

        btnAdd.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private void alignTableColumn(JTable table, int colIndex, int alignment) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(alignment);
        table.getColumnModel().getColumn(colIndex).setCellRenderer(renderer);
    }
}

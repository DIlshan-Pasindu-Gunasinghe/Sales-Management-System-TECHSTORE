package com.ead.sales;

import com.ead.sales.config.DBConnection;
import com.ead.sales.service.ReportService;
import net.sf.jasperreports.engine.JasperPrint;

public class TestReport {
    public static void main(String[] args) {
        try {
            System.out.println("Testing DB connection...");
            java.sql.Connection conn = DBConnection.getInstance().getConnection();
            System.out.println("DB connected: " + (conn != null && !conn.isClosed()));

            System.out.println("\n=== Testing Sales Decision Report ===");
            ReportService service = ReportService.getInstance();
            JasperPrint print = service.generateDecisionMakingReport("Test User");
            System.out.println("SUCCESS: Decision report generated. Pages: " + print.getPages().size());

        } catch (Exception ex) {
            System.err.println("FAILED: " + ex.getClass().getName() + ": " + ex.getMessage());
            ex.printStackTrace();
        }

        try {
            System.out.println("\n=== Testing Inventory Report ===");
            ReportService service = ReportService.getInstance();
            JasperPrint print = service.generateInventoryReport();
            System.out.println("SUCCESS: Inventory report generated. Pages: " + print.getPages().size());
        } catch (Exception ex) {
            System.err.println("FAILED: " + ex.getClass().getName() + ": " + ex.getMessage());
            ex.printStackTrace();
        }

        try {
            System.out.println("\n=== Testing Receipt Report (order_id=1) ===");
            ReportService service = ReportService.getInstance();
            JasperPrint print = service.generateReceipt(1);
            System.out.println("SUCCESS: Receipt report generated. Pages: " + print.getPages().size());
        } catch (Exception ex) {
            System.err.println("FAILED: " + ex.getClass().getName() + ": " + ex.getMessage());
            ex.printStackTrace();
        }

        System.out.println("\nDone.");
        System.exit(0);
    }
}

package com.ead.sales.util;

/**
 * Custom exception for business logic and UI validation failures.
 */
public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
}

package com.ead.sales.view;

import com.ead.sales.model.User;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * MainDashboardFrame: Core Application Container
 * Provides persistent navigation sidebar, user session tracking, live clock,
 * and seamless CardLayout routing across all application views.
 */
public class MainDashboardFrame extends JFrame {

    private final User currentUser;

    private JPanel centerCardPanel;
    private CardLayout cardLayout;

    private DashboardPanel dashboardPanel;
    private TransactionPanel transactionPanel;
    private ProductManagementPanel productPanel;
    private CustomerManagementPanel customerPanel;
    private OrderHistoryPanel orderHistoryPanel;
    private ReportsPanel reportsPanel;

    private final Map<String, JButton> navButtons = new HashMap<>();

    public MainDashboardFrame(User user) {
        this.currentUser = user;
        initComponents();
    }

    private void initComponents() {
        setTitle("Sales Management System - TechStore POS");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1340, 840);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);

        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UITheme.BG_LIGHT);

        // TOP HEADER BAR
        JPanel headerBar = new JPanel(new BorderLayout());
        headerBar.setBackground(UITheme.PRIMARY_DARK);
        headerBar.setBorder(new EmptyBorder(12, 20, 12, 20));

        // Brand Title
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        brandPanel.setOpaque(false);

        JLabel lblBrand = new JLabel("TECHSTORE");
        lblBrand.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblBrand.setForeground(Color.WHITE);

        JLabel lblModule = new JLabel("| Sales & POS System");
        lblModule.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblModule.setForeground(UITheme.PRIMARY_LIGHT);

        brandPanel.add(lblBrand);
        brandPanel.add(lblModule);
        headerBar.add(brandPanel, BorderLayout.WEST);

        // User & Session Info
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        userPanel.setOpaque(false);

        JLabel lblClock = new JLabel();
        lblClock.setFont(UITheme.FONT_REGULAR);
        lblClock.setForeground(UITheme.PRIMARY_LIGHT);
        startClockTimer(lblClock);

        JLabel lblUserBadge = new JLabel(currentUser.getFullName() + " [" + currentUser.getRole() + "]");
        lblUserBadge.setFont(UITheme.FONT_BOLD);
        lblUserBadge.setForeground(Color.WHITE);
        lblUserBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 60), 1, true),
                new EmptyBorder(4, 10, 4, 10)
        ));

        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(UITheme.FONT_BOLD);
        btnLogout.setBackground(UITheme.DANGER);
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.setBorder(new EmptyBorder(5, 14, 5, 14));
        btnLogout.addActionListener(e -> handleLogout());

        userPanel.add(lblClock);
        userPanel.add(lblUserBadge);
        userPanel.add(btnLogout);
        headerBar.add(userPanel, BorderLayout.EAST);

        rootPanel.add(headerBar, BorderLayout.NORTH);

        // LEFT NAVIGATION SIDEBAR
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(UITheme.BG_DARK);
        sidebar.setPreferredSize(new Dimension(240, 0));
        sidebar.setBorder(new EmptyBorder(20, 12, 20, 12));

        JPanel navList = new JPanel(new GridLayout(6, 1, 0, 10));
        navList.setOpaque(false);

        navList.add(createNavButton("DASHBOARD", "Executive Dashboard"));
        navList.add(createNavButton("TRANSACTION", "Sales Terminal (POS)"));
        navList.add(createNavButton("PRODUCTS", "Products & Inventory"));
        navList.add(createNavButton("CUSTOMERS", "Customer CRM"));
        navList.add(createNavButton("ORDERS", "Order Invoices"));
        navList.add(createNavButton("REPORTS", "Decision Reports"));

        sidebar.add(navList, BorderLayout.NORTH);

        // NIBM Footer info in sidebar
        JLabel lblFooter = new JLabel("<html><center><small><br/>TECHSTORE</small></center></html>", SwingConstants.CENTER);
        lblFooter.setForeground(new Color(148, 163, 184));
        sidebar.add(lblFooter, BorderLayout.SOUTH);

        rootPanel.add(sidebar, BorderLayout.WEST);

        // CENTER VIEWS CONTAINER (CardLayout)
        cardLayout = new CardLayout();
        centerCardPanel = new JPanel(cardLayout);
        centerCardPanel.setBackground(UITheme.BG_LIGHT);

        // Initialize panels
        dashboardPanel = new DashboardPanel(this);
        transactionPanel = new TransactionPanel(currentUser);
        productPanel = new ProductManagementPanel();
        customerPanel = new CustomerManagementPanel();
        orderHistoryPanel = new OrderHistoryPanel();
        reportsPanel = new ReportsPanel(currentUser);

        centerCardPanel.add(dashboardPanel, "DASHBOARD");
        centerCardPanel.add(transactionPanel, "TRANSACTION");
        centerCardPanel.add(productPanel, "PRODUCTS");
        centerCardPanel.add(customerPanel, "CUSTOMERS");
        centerCardPanel.add(orderHistoryPanel, "ORDERS");
        centerCardPanel.add(reportsPanel, "REPORTS");

        rootPanel.add(centerCardPanel, BorderLayout.CENTER);

        setContentPane(rootPanel);

        // Default selection
        navigateTo("DASHBOARD");
    }

    private JButton createNavButton(String key, String title) {
        JButton btn = new JButton(title);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(12, 16, 12, 16));
        btn.setBackground(UITheme.BG_DARK);
        btn.setForeground(new Color(203, 213, 225));

        btn.addActionListener(e -> navigateTo(key));
        navButtons.put(key, btn);
        return btn;
    }

    public void navigateTo(String viewKey) {
        cardLayout.show(centerCardPanel, viewKey);

        // Highlight active button
        for (Map.Entry<String, JButton> entry : navButtons.entrySet()) {
            if (entry.getKey().equals(viewKey)) {
                entry.getValue().setBackground(UITheme.PRIMARY);
                entry.getValue().setForeground(Color.WHITE);
            } else {
                entry.getValue().setBackground(UITheme.BG_DARK);
                entry.getValue().setForeground(new Color(203, 213, 225));
            }
        }

        // Auto-refresh data when navigating to specific panels
        switch (viewKey) {
            case "DASHBOARD" -> dashboardPanel.refreshData();
            case "TRANSACTION" -> transactionPanel.loadInitialData();
            case "PRODUCTS" -> productPanel.loadProducts();
            case "CUSTOMERS" -> customerPanel.loadCustomers();
            case "ORDERS" -> orderHistoryPanel.loadOrders();
            case "REPORTS" -> reportsPanel.loadInvoices();
        }
    }

    private void handleLogout() {
        if (ExceptionHandler.confirm(this, "Are you sure you want to log out of the system?")) {
            dispose();
            SwingUtilities.invokeLater(() -> {
                LoginFrame login = new LoginFrame();
                login.setVisible(true);
            });
        }
    }

    private void startClockTimer(JLabel label) {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss");
        Timer timer = new Timer(1000, e -> label.setText(sdf.format(new Date())));
        timer.setInitialDelay(0);
        timer.start();
    }
}

package com.ead.sales.service;

import com.ead.sales.config.DBConnection;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.*;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service Pattern: ReportService
 * Handles compiling, data filling, interactive previewing, and PDF exporting
 * of JasperReports for executive decision-making.
 */
public class ReportService {

    private static final Logger LOGGER = Logger.getLogger(ReportService.class.getName());
    private static ReportService instance;
    private final Map<String, JasperReport> reportCache = new ConcurrentHashMap<>();

    private ReportService() {
    }

    public static synchronized ReportService getInstance() {
        if (instance == null) {
            instance = new ReportService();
        }
        return instance;
    }

    private synchronized JasperReport loadOrCompileReport(String reportName) throws Exception {
        if (reportCache.containsKey(reportName)) {
            return reportCache.get(reportName);
        }

        // 1. Check for pre-compiled .jasper file first
        String jasperPath = "reports/" + reportName + ".jasper";
        InputStream jasperStream = getClass().getClassLoader().getResourceAsStream(jasperPath);
        if (jasperStream != null) {
            try {
                JasperReport report = (JasperReport) net.sf.jasperreports.engine.util.JRLoader.loadObject(jasperStream);
                reportCache.put(reportName, report);
                LOGGER.info("Loaded precompiled Jasper report: " + jasperPath);
                return report;
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, "Could not load precompiled .jasper, falling back to JRXML: " + ex.getMessage());
            }
        }

        // 2. Load and compile .jrxml source
        String jrxmlPath = "reports/" + reportName + ".jrxml";
        InputStream jrxmlStream = getClass().getClassLoader().getResourceAsStream(jrxmlPath);
        if (jrxmlStream == null) {
            File file = new File("src/main/resources/" + jrxmlPath);
            if (file.exists()) {
                JasperReport report = JasperCompileManager.compileReport(file.getAbsolutePath());
                reportCache.put(reportName, report);
                return report;
            }
            throw new IllegalArgumentException("Report template not found: " + jrxmlPath);
        }

        JasperReport compiled = JasperCompileManager.compileReport(jrxmlStream);
        reportCache.put(reportName, compiled);
        LOGGER.info("Successfully compiled JRXML report: " + jrxmlPath);
        return compiled;
    }

    /**
     * Generates the multi-table Executive Sales & Profitability Decision Report
     */
    public JasperPrint generateDecisionMakingReport(String generatedBy) throws Exception {
        JasperReport report = loadOrCompileReport("sales_decision_report");
        Map<String, Object> params = new HashMap<>();
        params.put("REPORT_TITLE", "EXECUTIVE SALES PERFORMANCE & PROFITABILITY REPORT");
        params.put("GENERATED_BY", generatedBy != null ? generatedBy : "System Admin");

        Connection conn = DBConnection.getInstance().getConnection();
        return JasperFillManager.fillReport(report, params, conn);
    }

    /**
     * Generates individual Sales Receipt / Tax Invoice
     */
    public JasperPrint generateReceipt(int orderId) throws Exception {
        JasperReport report = loadOrCompileReport("sales_receipt");
        Map<String, Object> params = new HashMap<>();
        params.put("ORDER_ID", orderId);

        Connection conn = DBConnection.getInstance().getConnection();
        return JasperFillManager.fillReport(report, params, conn);
    }

    /**
     * Generates Inventory Low-Stock & Reorder Decision Report
     */
    public JasperPrint generateInventoryReport() throws Exception {
        JasperReport report = loadOrCompileReport("inventory_reorder_report");
        Map<String, Object> params = new HashMap<>();
        params.put("REPORT_TITLE", "INVENTORY LOW STOCK & REORDER DECISION REPORT");

        Connection conn = DBConnection.getInstance().getConnection();
        return JasperFillManager.fillReport(report, params, conn);
    }

    /**
     * Displays the interactive JasperViewer preview window
     */
    public void viewReport(JasperPrint print, String windowTitle) {
        SwingUtilities.invokeLater(() -> {
            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setTitle(windowTitle);
            viewer.setSize(1000, 750);
            viewer.setLocationRelativeTo(null);
            viewer.setVisible(true);
        });
    }

    /**
     * Exports JasperPrint directly to a PDF file
     */
    public void exportToPdf(JasperPrint print, File targetFile) throws Exception {
        if (!targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }
        JasperExportManager.exportReportToPdfFile(print, targetFile.getAbsolutePath());
        LOGGER.info("Report exported to PDF: " + targetFile.getAbsolutePath());
    }
}

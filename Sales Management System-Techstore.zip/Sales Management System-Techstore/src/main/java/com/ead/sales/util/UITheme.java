package com.ead.sales.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * UITheme — Modern Enterprise UI Design System
 * Dark navy sidebar + colorful KPI cards + clean rounded panels
 * Inspired by modern Java Swing dashboard designs (DJ-Raven style)
 */
public class UITheme {

    // ─── SIDEBAR ──────────────────────────────────────────────────────────────
    public static final Color SIDEBAR_BG        = new Color(0x1B2B4B);   // Dark navy
    public static final Color SIDEBAR_ACTIVE    = new Color(0x2D4270);   // Active item bg
    public static final Color SIDEBAR_TEXT      = new Color(0xB0BEC5);   // Inactive text
    public static final Color SIDEBAR_ACTIVE_TXT= Color.WHITE;
    public static final Color SIDEBAR_ACCENT    = new Color(0x2979FF);   // Left accent bar

    // ─── MAIN AREA ────────────────────────────────────────────────────────────
    public static final Color BG_CONTENT        = new Color(0xF0F4F8);   // Light grey bg
    public static final Color BG_WHITE          = Color.WHITE;
    public static final Color BG_LIGHT          = new Color(0xF0F4F8);   // alias
    public static final Color BG_DARK           = SIDEBAR_BG;            // alias

    // ─── HEADER ───────────────────────────────────────────────────────────────
    public static final Color HEADER_BG         = new Color(0x1B2B4B);
    public static final Color HEADER_TEXT       = Color.WHITE;
    public static final Color HEADER_SUBTEXT    = new Color(0x8DA3BC);

    // ─── KPI CARD COLORS ──────────────────────────────────────────────────────
    public static final Color CARD_BLUE         = new Color(0x2979FF);   // Total Sales
    public static final Color CARD_GREEN        = new Color(0x00C853);   // Today Revenue
    public static final Color CARD_ORANGE       = new Color(0xFF6D00);   // Products
    public static final Color CARD_RED          = new Color(0xD50000);   // Low Stock

    // ─── SEMANTIC COLORS ──────────────────────────────────────────────────────
    public static final Color PRIMARY           = new Color(0x2979FF);
    public static final Color PRIMARY_DARK      = new Color(0x1565C0);
    public static final Color PRIMARY_LIGHT     = new Color(0x82B1FF);
    public static final Color SUCCESS           = new Color(0x00C853);
    public static final Color DANGER            = new Color(0xD50000);
    public static final Color WARNING           = new Color(0xFF6D00);
    public static final Color INFO              = new Color(0x00B0FF);

    // ─── TEXT ─────────────────────────────────────────────────────────────────
    public static final Color TEXT_MAIN         = new Color(0x1A2B47);
    public static final Color TEXT_MUTED        = new Color(0x607D8B);
    public static final Color TEXT_LIGHT        = new Color(0xB0BEC5);
    public static final Color BORDER_COLOR      = new Color(0xDDE3EC);

    // ─── TABLE ────────────────────────────────────────────────────────────────
    public static final Color TABLE_HEADER_BG   = new Color(0x1B2B4B);
    public static final Color TABLE_ROW_ODD     = Color.WHITE;
    public static final Color TABLE_ROW_EVEN    = new Color(0xF7F9FC);
    public static final Color TABLE_SELECTED    = new Color(0xBBDEFB);
    public static final Color TABLE_GRID        = new Color(0xECF0F5);

    // ─── TYPOGRAPHY ───────────────────────────────────────────────────────────
    public static final Font FONT_APP_TITLE     = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font FONT_NAV           = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_TITLE         = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_SUBTITLE      = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_BOLD          = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font FONT_REGULAR       = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font FONT_SMALL         = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_KPI_VALUE     = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font FONT_KPI_LABEL     = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font FONT_KPI_NUMBER    = FONT_KPI_VALUE; // alias

    // ─── SETUP ────────────────────────────────────────────────────────────────
    public static void setupTheme() {
        try {
            com.formdev.flatlaf.FlatLightLaf.setup();
            UIManager.put("defaultFont",              FONT_REGULAR);
            UIManager.put("Button.arc",               8);
            UIManager.put("Component.arc",            8);
            UIManager.put("TextComponent.arc",        6);
            UIManager.put("ScrollBar.width",          6);
            UIManager.put("Table.showHorizontalLines",true);
            UIManager.put("Table.showVerticalLines",  false);
        } catch (Exception e) {
            System.err.println("FlatLaf init error: " + e.getMessage());
        }
    }

    // ─── ROUNDED CARD PANEL ───────────────────────────────────────────────────
    public static JPanel createCardPanel() {
        return new RoundedPanel(12, BG_WHITE, new Color(0, 0, 0, 15), 4);
    }

    public static JPanel createCardPanel(Color bg) {
        return new RoundedPanel(12, bg, new Color(0, 0, 0, 18), 4);
    }

    // ─── KPI CARD ─────────────────────────────────────────────────────────────
    public static JPanel createKpiCard(String title, JLabel valueLabel, String subtitle, Color color) {
        JPanel card = new RoundedPanel(14, color, null, 0);
        card.setLayout(new BorderLayout(0, 6));
        card.setBorder(new EmptyBorder(20, 22, 20, 22));

        JLabel lblTitle = new JLabel(title.toUpperCase());
        lblTitle.setFont(FONT_KPI_LABEL);
        lblTitle.setForeground(new Color(255, 255, 255, 200));

        valueLabel.setFont(FONT_KPI_VALUE);
        valueLabel.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(FONT_SMALL);
        lblSub.setForeground(new Color(255, 255, 255, 160));

        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        topRow.add(lblTitle, BorderLayout.WEST);

        card.add(topRow, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(lblSub, BorderLayout.SOUTH);

        return card;
    }

    // ─── BUTTON FACTORY ───────────────────────────────────────────────────────
    public static JButton createPrimaryButton(String text) {
        return makeButton(text, PRIMARY, Color.WHITE);
    }

    public static JButton createSuccessButton(String text) {
        return makeButton(text, SUCCESS, Color.WHITE);
    }

    public static JButton createDangerButton(String text) {
        return makeButton(text, DANGER, Color.WHITE);
    }

    public static JButton createWarningButton(String text) {
        return makeButton(text, WARNING, Color.WHITE);
    }

    public static JButton createOutlineButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BOLD);
        btn.setForeground(PRIMARY);
        btn.setBackground(new Color(0xE3F2FD));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xBBDEFB), 1, true),
                new EmptyBorder(6, 14, 6, 14)
        ));
        return btn;
    }

    public static JButton createSecondaryButton(String text) {
        return makeButton(text, new Color(0x607D8B), Color.WHITE);
    }

    private static JButton makeButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BOLD);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setBorder(new EmptyBorder(7, 18, 7, 18));
        return btn;
    }

    // ─── SECTION HEADER ───────────────────────────────────────────────────────
    public static JPanel createSectionHeader(String title, JButton... actionButtons) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(0, 0, 12, 0));

        JLabel lbl = new JLabel(title);
        lbl.setFont(FONT_SUBTITLE);
        lbl.setForeground(TEXT_MAIN);
        panel.add(lbl, BorderLayout.WEST);

        if (actionButtons != null && actionButtons.length > 0) {
            JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
            btnPanel.setOpaque(false);
            for (JButton btn : actionButtons) {
                btn.setFont(FONT_SMALL);
                btnPanel.add(btn);
            }
            panel.add(btnPanel, BorderLayout.EAST);
        }
        return panel;
    }

    // ─── STYLED TABLE ─────────────────────────────────────────────────────────
    public static void styleTable(JTable table) {
        table.setFont(FONT_REGULAR);
        table.setRowHeight(36);
        table.setShowGrid(true);
        table.setGridColor(TABLE_GRID);
        table.setSelectionBackground(TABLE_SELECTED);
        table.setSelectionForeground(TEXT_MAIN);
        table.setFocusable(false);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setFont(FONT_BOLD);
        table.getTableHeader().setBackground(TABLE_HEADER_BG);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(0, 36));

        // Alternating row colors
        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value,
                    boolean isSelected, boolean hasFocus, int row, int col) {
                super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, col);
                if (!isSelected) {
                    setBackground(row % 2 == 0 ? TABLE_ROW_ODD : TABLE_ROW_EVEN);
                }
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        });
    }

    public static JScrollPane createStyledScrollPane(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        sp.getViewport().setBackground(BG_WHITE);
        return sp;
    }

    // ─── STYLED FORM FIELDS ───────────────────────────────────────────────────
    public static JTextField createTextField(String placeholder) {
        JTextField tf = new JTextField();
        tf.setFont(FONT_REGULAR);
        tf.setPreferredSize(new Dimension(200, 36));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(4, 10, 4, 10)
        ));
        return tf;
    }

    public static JLabel createFormLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_BOLD);
        lbl.setForeground(TEXT_MUTED);
        return lbl;
    }

    public static JPanel createPageHeader(String title, String subtitle) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(0, 0, 20, 0));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(FONT_TITLE);
        lblTitle.setForeground(TEXT_MAIN);

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(FONT_REGULAR);
        lblSub.setForeground(TEXT_MUTED);

        panel.add(lblTitle, BorderLayout.NORTH);
        panel.add(lblSub, BorderLayout.CENTER);
        return panel;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  INNER CLASS: RoundedPanel with shadow
    // ══════════════════════════════════════════════════════════════════════════
    public static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color shadowColor;
        private final int shadowSize;

        public RoundedPanel(int radius, Color background, Color shadowColor, int shadowSize) {
            super();
            this.radius = radius;
            this.shadowColor = shadowColor;
            this.shadowSize = shadowSize;
            setBackground(background);
            setOpaque(false);
            if (shadowSize > 0) {
                setBorder(new EmptyBorder(shadowSize, shadowSize, shadowSize + 2, shadowSize + 2));
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int x = shadowSize;
            int y = shadowSize;
            int w = getWidth()  - shadowSize * 2 - 2;
            int h = getHeight() - shadowSize * 2 - 2;

            // Draw shadow
            if (shadowColor != null && shadowSize > 0) {
                for (int i = shadowSize; i >= 1; i--) {
                    int alpha = (int) (25.0 / i);
                    g2.setColor(new Color(0, 0, 0, Math.min(alpha, 40)));
                    g2.fill(new RoundRectangle2D.Double(x + i, y + i, w, h, radius, radius));
                }
            }

            // Draw background
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Double(x, y, w, h, radius, radius));
            g2.dispose();
            super.paintComponent(g);
        }
    }
}

package com.ead.sales.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Order Entity Model
 * Represents a completed sales invoice/order
 */
public class Order {
    private int orderId;
    private String invoiceNo;
    private int customerId;
    private String customerName;
    private String customerPhone;
    private int userId;
    private String cashierName;
    private Timestamp orderDate;
    private BigDecimal subtotal;
    private BigDecimal discountAmount;
    private BigDecimal taxAmount;
    private BigDecimal grandTotal;
    private String paymentMethod; // CASH, CARD, ONLINE
    private BigDecimal amountPaid;
    private BigDecimal balanceReturned;
    private String status; // COMPLETED, CANCELLED
    private String notes;
    private List<OrderItem> items = new ArrayList<>();

    public Order() {
        this.subtotal = BigDecimal.ZERO;
        this.discountAmount = BigDecimal.ZERO;
        this.taxAmount = BigDecimal.ZERO;
        this.grandTotal = BigDecimal.ZERO;
        this.amountPaid = BigDecimal.ZERO;
        this.balanceReturned = BigDecimal.ZERO;
        this.paymentMethod = "CASH";
        this.status = "COMPLETED";
    }

    public void addItem(OrderItem item) {
        items.add(item);
        recalculateTotals();
    }

    public void removeItem(int index) {
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            recalculateTotals();
        }
    }

    public void recalculateTotals() {
        BigDecimal sum = BigDecimal.ZERO;
        for (OrderItem item : items) {
            sum = sum.add(item.getTotalPrice());
        }
        this.subtotal = sum;
        if (this.discountAmount == null) this.discountAmount = BigDecimal.ZERO;
        if (this.taxAmount == null) this.taxAmount = BigDecimal.ZERO;
        this.grandTotal = this.subtotal.subtract(this.discountAmount).add(this.taxAmount);
        if (this.grandTotal.compareTo(BigDecimal.ZERO) < 0) {
            this.grandTotal = BigDecimal.ZERO;
        }
        if (this.amountPaid != null && this.amountPaid.compareTo(BigDecimal.ZERO) > 0) {
            this.balanceReturned = this.amountPaid.subtract(this.grandTotal);
        } else {
            this.balanceReturned = BigDecimal.ZERO;
        }
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getCashierName() {
        return cashierName;
    }

    public void setCashierName(String cashierName) {
        this.cashierName = cashierName;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
        recalculateTotals();
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
        recalculateTotals();
    }

    public BigDecimal getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(BigDecimal grandTotal) {
        this.grandTotal = grandTotal;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public BigDecimal getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(BigDecimal amountPaid) {
        this.amountPaid = amountPaid;
        recalculateTotals();
    }

    public BigDecimal getBalanceReturned() {
        return balanceReturned;
    }

    public void setBalanceReturned(BigDecimal balanceReturned) {
        this.balanceReturned = balanceReturned;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public void setItems(List<OrderItem> items) {
        this.items = items;
        recalculateTotals();
    }

    @Override
    public String toString() {
        return invoiceNo + " - " + (customerName != null ? customerName : "Walk-in Customer") 
                + " (LKR " + (grandTotal != null ? grandTotal : "0.00") + ")";
    }
}

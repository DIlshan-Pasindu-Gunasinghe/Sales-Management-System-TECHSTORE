package com.ead.sales.util;

import net.sf.jasperreports.engine.JasperCompileManager;

import java.io.File;

/**
 * Utility to pre-compile all JRXML report templates to binary .jasper files.
 */
public class ReportCompilerUtil {
    public static void main(String[] args) {
        String reportsDir = "src/main/resources/reports";
        File dir = new File(reportsDir);
        if (!dir.exists()) {
            System.err.println("Reports directory not found: " + dir.getAbsolutePath());
            return;
        }

        File[] files = dir.listFiles((d, name) -> name.endsWith(".jrxml"));
        if (files == null || files.length == 0) {
            System.out.println("No JRXML templates found in " + reportsDir);
            return;
        }

        for (File jrxml : files) {
            String jasperPath = jrxml.getAbsolutePath().replace(".jrxml", ".jasper");
            try {
                System.out.println("Compiling: " + jrxml.getName() + " -> " + new File(jasperPath).getName());
                JasperCompileManager.compileReportToFile(jrxml.getAbsolutePath(), jasperPath);
                System.out.println("SUCCESS: Compiled " + new File(jasperPath).getName());
            } catch (Exception ex) {
                System.err.println("ERROR compiling " + jrxml.getName() + ": " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
}

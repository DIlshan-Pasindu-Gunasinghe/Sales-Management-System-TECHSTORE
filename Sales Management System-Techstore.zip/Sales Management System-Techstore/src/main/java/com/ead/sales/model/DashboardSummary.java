package com.ead.sales.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Dashboard Summary DTO
 * Aggregates high-level metrics for the executive dashboard
 */
public class DashboardSummary {
    private BigDecimal todayRevenue = BigDecimal.ZERO;
    private BigDecimal monthRevenue = BigDecimal.ZERO;
    private int todayOrderCount = 0;
    private int monthOrderCount = 0;
    private int totalProducts = 0;
    private int lowStockCount = 0;
    private int totalCustomers = 0;
    private List<Order> recentOrders = new ArrayList<>();
    private List<Product> lowStockProducts = new ArrayList<>();

    public DashboardSummary() {
    }

    public BigDecimal getTodayRevenue() {
        return todayRevenue;
    }

    public void setTodayRevenue(BigDecimal todayRevenue) {
        this.todayRevenue = todayRevenue;
    }

    public BigDecimal getMonthRevenue() {
        return monthRevenue;
    }

    public void setMonthRevenue(BigDecimal monthRevenue) {
        this.monthRevenue = monthRevenue;
    }

    public int getTodayOrderCount() {
        return todayOrderCount;
    }

    public void setTodayOrderCount(int todayOrderCount) {
        this.todayOrderCount = todayOrderCount;
    }

    public int getMonthOrderCount() {
        return monthOrderCount;
    }

    public void setMonthOrderCount(int monthOrderCount) {
        this.monthOrderCount = monthOrderCount;
    }

    public int getTotalProducts() {
        return totalProducts;
    }

    public void setTotalProducts(int totalProducts) {
        this.totalProducts = totalProducts;
    }

    public int getLowStockCount() {
        return lowStockCount;
    }

    public void setLowStockCount(int lowStockCount) {
        this.lowStockCount = lowStockCount;
    }

    public int getTotalCustomers() {
        return totalCustomers;
    }

    public void setTotalCustomers(int totalCustomers) {
        this.totalCustomers = totalCustomers;
    }

    public List<Order> getRecentOrders() {
        return recentOrders;
    }

    public void setRecentOrders(List<Order> recentOrders) {
        this.recentOrders = recentOrders;
    }

    public List<Product> getLowStockProducts() {
        return lowStockProducts;
    }

    public void setLowStockProducts(List<Product> lowStockProducts) {
        this.lowStockProducts = lowStockProducts;
    }
}

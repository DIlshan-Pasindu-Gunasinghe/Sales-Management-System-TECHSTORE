package com.ead.sales.model;

import java.math.BigDecimal;

/**
 * OrderItem Entity Model
 * Represents an individual line item inside a sales order
 */
public class OrderItem {
    private int orderItemId;
    private int orderId;
    private int productId;
    private String productCode;
    private String productName;
    private BigDecimal unitCostPrice;
    private BigDecimal unitSellingPrice;
    private int quantity;
    private BigDecimal totalPrice;

    public OrderItem() {
    }

    public OrderItem(int productId, String productCode, String productName, BigDecimal unitCostPrice, 
                     BigDecimal unitSellingPrice, int quantity) {
        this.productId = productId;
        this.productCode = productCode;
        this.productName = productName;
        this.unitCostPrice = unitCostPrice;
        this.unitSellingPrice = unitSellingPrice;
        this.quantity = quantity;
        this.totalPrice = unitSellingPrice.multiply(BigDecimal.valueOf(quantity));
    }

    public int getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(int orderItemId) {
        this.orderItemId = orderItemId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getUnitCostPrice() {
        return unitCostPrice;
    }

    public void setUnitCostPrice(BigDecimal unitCostPrice) {
        this.unitCostPrice = unitCostPrice;
    }

    public BigDecimal getUnitSellingPrice() {
        return unitSellingPrice;
    }

    public void setUnitSellingPrice(BigDecimal unitSellingPrice) {
        this.unitSellingPrice = unitSellingPrice;
        if (quantity > 0 && unitSellingPrice != null) {
            this.totalPrice = unitSellingPrice.multiply(BigDecimal.valueOf(quantity));
        }
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        if (unitSellingPrice != null) {
            this.totalPrice = unitSellingPrice.multiply(BigDecimal.valueOf(quantity));
        }
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }
}

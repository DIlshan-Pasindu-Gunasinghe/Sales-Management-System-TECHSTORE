package com.ead.sales.view;

import com.ead.sales.dao.DAOFactory;
import com.ead.sales.model.Order;
import com.ead.sales.model.User;
import com.ead.sales.service.ReportService;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;
import net.sf.jasperreports.engine.JasperPrint;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ReportsPanel: Executive Decision-Making & Reporting Hub
 * Generates JasperReports across multiple relational tables to aid strategic decisions.
 */
public class ReportsPanel extends JPanel {

    private static final Logger LOGGER = Logger.getLogger(ReportsPanel.class.getName());
    private final User currentUser;
    private final ReportService reportService = ReportService.getInstance();

    private JComboBox<Order> cmbInvoices;

    public ReportsPanel(User user) {
        this.currentUser = user;
        initComponents();
        loadInvoices();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG_LIGHT);
        setBorder(new EmptyBorder(20, 25, 20, 25));

        // Top Header
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JLabel lblTitle = new JLabel("Executive Decision Reports & Analytics");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_MAIN);

        JLabel lblSubtitle = new JLabel("JasperReports Engine Integration - Multi-Table Decision Analysis");
        lblSubtitle.setFont(UITheme.FONT_REGULAR);
        lblSubtitle.setForeground(UITheme.TEXT_MUTED);

        topBar.add(lblTitle, BorderLayout.NORTH);
        topBar.add(lblSubtitle, BorderLayout.SOUTH);
        add(topBar, BorderLayout.NORTH);

        // Center: Cards for each report
        JPanel cardsContainer = new JPanel(new GridLayout(3, 1, 0, 16));
        cardsContainer.setOpaque(false);

        // CARD 1: Executive Sales & Profitability Decision Report (Major Report)
        cardsContainer.add(createReportCard(
                "1. Executive Sales Performance & Profitability Report (Major Decision Report)",
                "Relational Tables Involved: orders, order_items, products, categories, customers (5 Tables)",
                "Decision-Making Purpose: Crucial for management to identify high-margin vs low-margin products, "
                + "analyze category revenue contributions, review customer spend profiles, and make evidence-based purchasing/pricing decisions.",
                e -> previewDecisionReport(),
                e -> exportDecisionReportPdf(),
                UITheme.PRIMARY
        ));

        // CARD 2: Inventory Low-Stock & Reorder Report
        cardsContainer.add(createReportCard(
                "2. Inventory Reorder & Procurement Decision Report",
                "Relational Tables Involved: products, categories (2 Tables)",
                "Decision-Making Purpose: Directs purchasing managers on critical stock shortages below safety thresholds, "
                + "recommends optimal restock quantities, and estimates required procurement capital investment.",
                e -> previewInventoryReport(),
                e -> exportInventoryReportPdf(),
                UITheme.DANGER
        ));

        // CARD 3: Sales Order Invoice / Customer Receipt
        JPanel invoiceCard = UITheme.createCardPanel();
        invoiceCard.setLayout(new BorderLayout(10, 10));
        invoiceCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, UITheme.SUCCESS),
                new EmptyBorder(12, 16, 12, 16)
        ));

        JPanel invoiceHeader = new JPanel(new GridLayout(2, 1, 2, 2));
        invoiceHeader.setOpaque(false);
        JLabel lblInvTitle = new JLabel("3. Sales Invoice & Receipt Document");
        lblInvTitle.setFont(UITheme.FONT_SUBTITLE);
        lblInvTitle.setForeground(UITheme.TEXT_MAIN);

        JLabel lblInvSub = new JLabel("Generates printable tax invoices for customer transactions with line-item breakdown.");
        lblInvSub.setFont(UITheme.FONT_REGULAR);
        lblInvSub.setForeground(UITheme.TEXT_MUTED);

        invoiceHeader.add(lblInvTitle);
        invoiceHeader.add(lblInvSub);
        invoiceCard.add(invoiceHeader, BorderLayout.NORTH);

        JPanel invoiceActions = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 5));
        invoiceActions.setOpaque(false);

        invoiceActions.add(new JLabel("Select Invoice:"));
        cmbInvoices = new JComboBox<>();
        cmbInvoices.setPreferredSize(new Dimension(280, 32));
        invoiceActions.add(cmbInvoices);

        JButton btnViewInv = UITheme.createPrimaryButton("Preview Invoice (Jasper)");
        btnViewInv.addActionListener(e -> previewSelectedInvoice());
        invoiceActions.add(btnViewInv);

        JButton btnExportInv = UITheme.createSuccessButton("Export Invoice PDF");
        btnExportInv.addActionListener(e -> exportSelectedInvoicePdf());
        invoiceActions.add(btnExportInv);

        invoiceCard.add(invoiceActions, BorderLayout.CENTER);
        cardsContainer.add(invoiceCard);

        add(cardsContainer, BorderLayout.CENTER);
    }

    private JPanel createReportCard(String title, String tablesTag, String description,
                                     java.awt.event.ActionListener onPreview,
                                     java.awt.event.ActionListener onExport,
                                     Color accentColor) {
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accentColor),
                new EmptyBorder(12, 16, 12, 16)
        ));

        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 2, 4));
        infoPanel.setOpaque(false);

        JLabel lblT = new JLabel(title);
        lblT.setFont(UITheme.FONT_SUBTITLE);
        lblT.setForeground(UITheme.TEXT_MAIN);

        JLabel lblTag = new JLabel(tablesTag);
        lblTag.setFont(UITheme.FONT_BOLD);
        lblTag.setForeground(accentColor);

        JLabel lblDesc = new JLabel("<html>" + description + "</html>");
        lblDesc.setFont(UITheme.FONT_REGULAR);
        lblDesc.setForeground(UITheme.TEXT_MUTED);

        infoPanel.add(lblT);
        infoPanel.add(lblTag);
        infoPanel.add(lblDesc);
        card.add(infoPanel, BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        actionPanel.setOpaque(false);

        JButton btnPreview = UITheme.createPrimaryButton("Interactive Preview");
        btnPreview.addActionListener(onPreview);

        JButton btnExport = UITheme.createSuccessButton("Export to PDF");
        btnExport.addActionListener(onExport);

        actionPanel.add(btnPreview);
        actionPanel.add(btnExport);
        card.add(actionPanel, BorderLayout.SOUTH);

        return card;
    }

    public void loadInvoices() {
        List<Order> orders = DAOFactory.getInstance().getOrderDAO().getAllOrders();
        cmbInvoices.removeAllItems();
        for (Order o : orders) {
            cmbInvoices.addItem(o);
        }
    }

    // Handlers for Report 1
    private void previewDecisionReport() {
        try {
            JasperPrint print = reportService.generateDecisionMakingReport(currentUser.getFullName());
            reportService.viewReport(print, "Executive Sales & Profitability Decision Report");
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Failed to generate decision report", ex);
            String rootCause = ex.getCause() != null ? "\nRoot Cause: " + ex.getCause().getMessage() : "";
            ExceptionHandler.showError(this, "Failed to compile/generate decision report:\n" 
                    + ex.getClass().getSimpleName() + ": " + ex.getMessage() + rootCause);
        }
    }

    private void exportDecisionReportPdf() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("Executive_Sales_Profitability_Report.pdf"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File target = chooser.getSelectedFile();
            try {
                JasperPrint print = reportService.generateDecisionMakingReport(currentUser.getFullName());
                reportService.exportToPdf(print, target);
                ExceptionHandler.showSuccess(this, "Decision Report exported successfully to:\n" + target.getAbsolutePath());
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Failed to export decision report", ex);
                String rootCause = ex.getCause() != null ? "\nRoot Cause: " + ex.getCause().getMessage() : "";
                ExceptionHandler.showError(this, "Export failed:\n" 
                        + ex.getClass().getSimpleName() + ": " + ex.getMessage() + rootCause);
            }
        }
    }

    // Handlers for Report 2
    private void previewInventoryReport() {
        try {
            JasperPrint print = reportService.generateInventoryReport();
            reportService.viewReport(print, "Inventory Reorder Decision Report");
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Failed to generate inventory report", ex);
            String rootCause = ex.getCause() != null ? "\nRoot Cause: " + ex.getCause().getMessage() : "";
            ExceptionHandler.showError(this, "Failed to generate inventory report:\n" 
                    + ex.getClass().getSimpleName() + ": " + ex.getMessage() + rootCause);
        }
    }

    private void exportInventoryReportPdf() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("Inventory_Reorder_Report.pdf"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File target = chooser.getSelectedFile();
            try {
                JasperPrint print = reportService.generateInventoryReport();
                reportService.exportToPdf(print, target);
                ExceptionHandler.showSuccess(this, "Inventory Report exported to:\n" + target.getAbsolutePath());
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Failed to export inventory report", ex);
                String rootCause = ex.getCause() != null ? "\nRoot Cause: " + ex.getCause().getMessage() : "";
                ExceptionHandler.showError(this, "Export failed:\n" 
                        + ex.getClass().getSimpleName() + ": " + ex.getMessage() + rootCause);
            }
        }
    }

    // Handlers for Report 3
    private void previewSelectedInvoice() {
        Order selected = (Order) cmbInvoices.getSelectedItem();
        if (selected == null) {
            ExceptionHandler.showWarning(this, "Please select an invoice.");
            return;
        }
        try {
            JasperPrint print = reportService.generateReceipt(selected.getOrderId());
            reportService.viewReport(print, "Tax Invoice Receipt: " + selected.getInvoiceNo());
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Failed to preview invoice", ex);
            String rootCause = ex.getCause() != null ? "\nRoot Cause: " + ex.getCause().getMessage() : "";
            ExceptionHandler.showError(this, "Failed to preview invoice:\n" 
                    + ex.getClass().getSimpleName() + ": " + ex.getMessage() + rootCause);
        }
    }

    private void exportSelectedInvoicePdf() {
        Order selected = (Order) cmbInvoices.getSelectedItem();
        if (selected == null) {
            ExceptionHandler.showWarning(this, "Please select an invoice.");
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("Invoice_" + selected.getInvoiceNo() + ".pdf"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File target = chooser.getSelectedFile();
            try {
                JasperPrint print = reportService.generateReceipt(selected.getOrderId());
                reportService.exportToPdf(print, target);
                ExceptionHandler.showSuccess(this, "Invoice PDF saved to:\n" + target.getAbsolutePath());
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Failed to export invoice PDF", ex);
                String rootCause = ex.getCause() != null ? "\nRoot Cause: " + ex.getCause().getMessage() : "";
                ExceptionHandler.showError(this, "Export failed:\n" 
                        + ex.getClass().getSimpleName() + ": " + ex.getMessage() + rootCause);
            }
        }
    }
}

package com.ead.sales.dao;

import com.ead.sales.config.DBConnection;
import com.ead.sales.model.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DAO Pattern: CustomerDAO
 * Handles all database persistence for Customer Management
 */
public class CustomerDAO {

    private static final Logger LOGGER = Logger.getLogger(CustomerDAO.class.getName());

    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT customer_id, customer_code, name, phone, email, address, loyalty_points, created_at "
                   + "FROM customers ORDER BY name ASC";

        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapCustomer(rs));
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving customers", ex);
        }
        return list;
    }

    public Customer getCustomerById(int customerId) {
        String sql = "SELECT customer_id, customer_code, name, phone, email, address, loyalty_points, created_at "
                   + "FROM customers WHERE customer_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return mapCustomer(rs);
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving customer ID: " + customerId, ex);
        }
        return null;
    }

    public List<Customer> searchCustomers(String keyword) {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT customer_id, customer_code, name, phone, email, address, loyalty_points, created_at "
                   + "FROM customers WHERE name LIKE ? OR phone LIKE ? OR customer_code LIKE ? ORDER BY name ASC";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                String term = "%" + keyword + "%";
                stmt.setString(1, term);
                stmt.setString(2, term);
                stmt.setString(3, term);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapCustomer(rs));
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error searching customers with keyword: " + keyword, ex);
        }
        return list;
    }

    public boolean addCustomer(Customer customer) {
        String sql = "INSERT INTO customers (customer_code, name, phone, email, address, loyalty_points) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, customer.getCustomerCode());
                stmt.setString(2, customer.getName());
                stmt.setString(3, customer.getPhone());
                stmt.setString(4, customer.getEmail());
                stmt.setString(5, customer.getAddress());
                stmt.setInt(6, customer.getLoyaltyPoints());

                int affected = stmt.executeUpdate();
                if (affected > 0) {
                    try (ResultSet keys = stmt.getGeneratedKeys()) {
                        if (keys.next()) {
                            customer.setCustomerId(keys.getInt(1));
                        }
                    }
                    return true;
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error adding customer: " + customer.getName(), ex);
        }
        return false;
    }

    public boolean updateCustomer(Customer customer) {
        String sql = "UPDATE customers SET name = ?, phone = ?, email = ?, address = ?, loyalty_points = ? WHERE customer_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, customer.getName());
                stmt.setString(2, customer.getPhone());
                stmt.setString(3, customer.getEmail());
                stmt.setString(4, customer.getAddress());
                stmt.setInt(5, customer.getLoyaltyPoints());
                stmt.setInt(6, customer.getCustomerId());
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error updating customer ID: " + customer.getCustomerId(), ex);
        }
        return false;
    }

    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM customers WHERE customer_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error deleting customer ID: " + customerId, ex);
        }
        return false;
    }

    public String generateNextCustomerCode() {
        String sql = "SELECT MAX(customer_id) AS max_id FROM customers";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int next = rs.getInt("max_id") + 1;
                    return String.format("CUST-%03d", next);
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.WARNING, "Error generating next customer code", ex);
        }
        return "CUST-001";
    }

    private Customer mapCustomer(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setCustomerId(rs.getInt("customer_id"));
        c.setCustomerCode(rs.getString("customer_code"));
        c.setName(rs.getString("name"));
        c.setPhone(rs.getString("phone"));
        c.setEmail(rs.getString("email"));
        c.setAddress(rs.getString("address"));
        c.setLoyaltyPoints(rs.getInt("loyalty_points"));
        c.setCreatedAt(rs.getTimestamp("created_at"));
        return c;
    }
}

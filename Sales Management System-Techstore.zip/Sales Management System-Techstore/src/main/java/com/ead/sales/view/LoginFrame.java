package com.ead.sales.view;

import com.ead.sales.dao.DAOFactory;
import com.ead.sales.model.User;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * LoginFrame: Authentication UI
 * Secure login screen with credential validation and role-based entry.
 */
public class LoginFrame extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnDemoAdmin;
    private JButton btnDemoCashier;

    public LoginFrame() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Enterprise Sales System - Secure Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 560);
        setResizable(false);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UITheme.BG_LIGHT);

        // Header Panel (Branding)
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.PRIMARY);
        headerPanel.setBorder(new EmptyBorder(30, 25, 30, 25));

        JLabel lblTitle = new JLabel("TECHSTORE SALES", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSubtitle = new JLabel("Sales Management System", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubtitle.setForeground(UITheme.PRIMARY_LIGHT);

        headerPanel.add(lblTitle, BorderLayout.NORTH);
        headerPanel.add(lblSubtitle, BorderLayout.CENTER);

        // Form Card Panel
        JPanel cardWrapper = new JPanel(new GridBagLayout());
        cardWrapper.setBackground(UITheme.BG_LIGHT);
        cardWrapper.setBorder(new EmptyBorder(20, 25, 20, 25));

        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new GridBagLayout());
        formCard.setPreferredSize(new Dimension(380, 360));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.gridx = 0;

        // Welcome Text
        gbc.gridy = 0;
        JLabel lblWelcome = new JLabel("Sign In to Your Account");
        lblWelcome.setFont(UITheme.FONT_SUBTITLE);
        lblWelcome.setForeground(UITheme.TEXT_MAIN);
        formCard.add(lblWelcome, gbc);

        // Username Label
        gbc.gridy = 1;
        JLabel lblUser = new JLabel("Username");
        lblUser.setFont(UITheme.FONT_BOLD);
        lblUser.setForeground(UITheme.TEXT_MUTED);
        formCard.add(lblUser, gbc);

        // Username Input
        gbc.gridy = 2;
        txtUsername = new JTextField(20);
        txtUsername.setFont(UITheme.FONT_REGULAR);
        txtUsername.setPreferredSize(new Dimension(300, 38));
        formCard.add(txtUsername, gbc);

        // Password Label
        gbc.gridy = 3;
        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(UITheme.FONT_BOLD);
        lblPass.setForeground(UITheme.TEXT_MUTED);
        formCard.add(lblPass, gbc);

        // Password Input
        gbc.gridy = 4;
        txtPassword = new JPasswordField(20);
        txtPassword.setFont(UITheme.FONT_REGULAR);
        txtPassword.setPreferredSize(new Dimension(300, 38));
        formCard.add(txtPassword, gbc);

        // Login Button
        gbc.gridy = 5;
        gbc.insets = new Insets(16, 10, 8, 10);
        btnLogin = UITheme.createPrimaryButton("Sign In to Dashboard");
        btnLogin.setPreferredSize(new Dimension(300, 40));
        formCard.add(btnLogin, gbc);

        // Quick Demo Fill Buttons
        gbc.gridy = 6;
        gbc.insets = new Insets(8, 10, 4, 10);
        JPanel demoPanel = new JPanel(new GridLayout(1, 2, 8, 0));
        demoPanel.setOpaque(false);

        btnDemoAdmin = UITheme.createOutlineButton("Demo Admin");
        btnDemoCashier = UITheme.createOutlineButton("Demo Cashier");

        demoPanel.add(btnDemoAdmin);
        demoPanel.add(btnDemoCashier);
        formCard.add(demoPanel, gbc);

        cardWrapper.add(formCard);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(cardWrapper, BorderLayout.CENTER);

        setContentPane(mainPanel);

        // Event Listeners
        btnLogin.addActionListener(e -> performLogin());

        txtPassword.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performLogin();
                }
            }
        });

        btnDemoAdmin.addActionListener(e -> {
            txtUsername.setText("admin");
            txtPassword.setText("admin123");
        });

        btnDemoCashier.addActionListener(e -> {
            txtUsername.setText("cashier");
            txtPassword.setText("cashier123");
        });
    }

    private void performLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            ExceptionHandler.showWarning(this, "Please enter both username and password.");
            return;
        }

        try {
            User user = DAOFactory.getInstance().getUserDAO().authenticate(username, password);
            if (user != null) {
                // Open Main Dashboard
                dispose();
                SwingUtilities.invokeLater(() -> {
                    MainDashboardFrame dashboard = new MainDashboardFrame(user);
                    dashboard.setVisible(true);
                });
            } else {
                ExceptionHandler.showError(this, "Invalid credentials or inactive account! Please try again.");
            }
        } catch (Exception ex) {
            ExceptionHandler.showError(this, "Database connection error: " + ex.getMessage());
        }
    }
}

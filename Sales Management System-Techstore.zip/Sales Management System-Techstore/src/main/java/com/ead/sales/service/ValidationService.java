package com.ead.sales.service;

import com.ead.sales.util.ValidationException;

import java.math.BigDecimal;
import java.util.regex.Pattern;

/**
 * Service Pattern: ValidationService
 * Centralized business rule & format validation component.
 */
public class ValidationService {

    private static final Pattern EMAIL_PATTERN = 
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");

    private static final Pattern PHONE_PATTERN = 
            Pattern.compile("^(?:0|\\+94)?[0-9]{9,10}$");

    public static void validateNotEmpty(String value, String fieldName) throws ValidationException {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException(fieldName + " cannot be empty.");
        }
    }

    public static void validatePhone(String phone) throws ValidationException {
        if (phone != null && !phone.trim().isEmpty()) {
            String cleanPhone = phone.replaceAll("[\\s\\-\\(\\)]", "");
            if (!PHONE_PATTERN.matcher(cleanPhone).matches()) {
                throw new ValidationException("Invalid phone number format! (e.g., 0771234567).");
            }
        }
    }

    public static void validateEmail(String email) throws ValidationException {
        if (email != null && !email.trim().isEmpty()) {
            if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
                throw new ValidationException("Invalid email address format! (e.g., user@example.com).");
            }
        }
    }

    public static BigDecimal parsePositiveDecimal(String text, String fieldName) throws ValidationException {
        validateNotEmpty(text, fieldName);
        try {
            BigDecimal value = new BigDecimal(text.trim());
            if (value.compareTo(BigDecimal.ZERO) < 0) {
                throw new ValidationException(fieldName + " must be greater than or equal to 0.");
            }
            return value;
        } catch (NumberFormatException ex) {
            throw new ValidationException(fieldName + " must be a valid numeric amount.");
        }
    }

    public static int parsePositiveInt(String text, String fieldName) throws ValidationException {
        validateNotEmpty(text, fieldName);
        try {
            int value = Integer.parseInt(text.trim());
            if (value < 0) {
                throw new ValidationException(fieldName + " must be greater than or equal to 0.");
            }
            return value;
        } catch (NumberFormatException ex) {
            throw new ValidationException(fieldName + " must be an integer number.");
        }
    }

    public static void validatePayment(BigDecimal amountPaid, BigDecimal grandTotal) throws ValidationException {
        if (amountPaid == null || amountPaid.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException("Amount paid must be greater than zero.");
        }
        if (amountPaid.compareTo(grandTotal) < 0) {
            throw new ValidationException("Amount paid (Rs. " + amountPaid + ") is less than Grand Total (Rs. " + grandTotal + ").");
        }
    }
}

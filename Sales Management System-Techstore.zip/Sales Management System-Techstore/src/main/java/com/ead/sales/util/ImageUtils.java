package com.ead.sales.util;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class ImageUtils {

    public static ImageIcon scaleImage(String imagePath, int width, int height) {
        Image img = loadImage(imagePath);
        if (img == null) {
            return createDefaultProductIcon(width, height, "PROD");
        }
        Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImg);
    }

    private static Image loadImage(String path) {
        if (path == null || path.trim().isEmpty()) {
            return null;
        }

        // Strategy 1: Try as direct absolute/relative file path (works in IDE)
        File file = new File(path);
        if (file.exists() && file.isFile()) {
            try { return ImageIO.read(file); } catch (Exception ignored) {}
        }

        String cleanName = new File(path).getName();

        // Strategy 2: Try relative to project root  
        String[] fsRoots = {
            "src/main/resources/images/" + cleanName,
            "src/main/resources/images/products/" + cleanName,
            "target/classes/images/" + cleanName,
        };
        for (String p : fsRoots) {
            File f = new File(p);
            if (f.exists() && f.isFile()) {
                try { return ImageIO.read(f); } catch (Exception ignored) {}
            }
        }

        // Strategy 3: Classpath lookup with leading slash (absolute classpath)
        String[] classpathRoots = {
            "/images/" + cleanName,
            "/images/products/" + cleanName,
            "images/" + cleanName,
            "images/products/" + cleanName,
        };
        for (String cp : classpathRoots) {
            try {
                InputStream is = ImageUtils.class.getResourceAsStream(cp);
                if (is != null) {
                    Image img = ImageIO.read(is);
                    is.close();
                    if (img != null) return img;
                }
            } catch (Exception ignored) {}
        }

        return null;
    }

    public static ImageIcon createDefaultProductIcon(int width, int height, String label) {
        BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = bi.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Soft gradient rounded box
        GradientPaint gp = new GradientPaint(0, 0, new Color(236, 242, 255), width, height, new Color(218, 228, 250));
        g2.setPaint(gp);
        g2.fillRoundRect(2, 2, width - 4, height - 4, 12, 12);

        g2.setColor(new Color(180, 200, 235));
        g2.drawRoundRect(2, 2, width - 4, height - 4, 12, 12);

        // Subtle Box icon in center
        int cx = width / 2;
        int cy = height / 2;
        g2.setColor(new Color(79, 70, 229, 180));
        g2.fillRoundRect(cx - 16, cy - 18, 32, 26, 6, 6);
        g2.setColor(Color.WHITE);
        g2.fillRect(cx - 8, cy - 14, 16, 4);

        if (label != null && !label.isEmpty()) {
            g2.setFont(new Font("Segoe UI", Font.BOLD, Math.max(9, width / 9)));
            FontMetrics fm = g2.getFontMetrics();
            int strW = fm.stringWidth(label);
            g2.setColor(new Color(79, 70, 229));
            g2.drawString(label, cx - (strW / 2), cy + 18);
        }

        g2.dispose();
        return new ImageIcon(bi);
    }
}


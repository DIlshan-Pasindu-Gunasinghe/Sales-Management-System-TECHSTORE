package com.ead.sales.dao;

import com.ead.sales.config.DBConnection;
import com.ead.sales.model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DAO Pattern: ProductDAO
 * Handles all database persistence for Products & Inventory
 */
public class ProductDAO {

    private static final Logger LOGGER = Logger.getLogger(ProductDAO.class.getName());

    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.product_id, p.product_code, p.product_name, p.category_id, c.category_name, "
                   + "p.cost_price, p.selling_price, p.stock_quantity, p.reorder_level, p.barcode, p.created_at "
                   + "FROM products p "
                   + "LEFT JOIN categories c ON p.category_id = c.category_id "
                   + "ORDER BY p.product_name ASC";

        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapProduct(rs));
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving products", ex);
        }
        return list;
    }

    public Product getProductById(int productId) {
        String sql = "SELECT p.product_id, p.product_code, p.product_name, p.category_id, c.category_name, "
                   + "p.cost_price, p.selling_price, p.stock_quantity, p.reorder_level, p.barcode, p.created_at "
                   + "FROM products p "
                   + "LEFT JOIN categories c ON p.category_id = c.category_id "
                   + "WHERE p.product_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, productId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return mapProduct(rs);
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving product ID: " + productId, ex);
        }
        return null;
    }

    public Product getProductByCode(String code) {
        String sql = "SELECT p.product_id, p.product_code, p.product_name, p.category_id, c.category_name, "
                   + "p.cost_price, p.selling_price, p.stock_quantity, p.reorder_level, p.barcode, p.created_at "
                   + "FROM products p "
                   + "LEFT JOIN categories c ON p.category_id = c.category_id "
                   + "WHERE p.product_code = ? OR p.barcode = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, code);
                stmt.setString(2, code);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return mapProduct(rs);
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving product by code/barcode: " + code, ex);
        }
        return null;
    }

    public List<Product> searchProducts(String keyword, Integer categoryId) {
        List<Product> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT p.product_id, p.product_code, p.product_name, p.category_id, c.category_name, "
            + "p.cost_price, p.selling_price, p.stock_quantity, p.reorder_level, p.barcode, p.created_at "
            + "FROM products p "
            + "LEFT JOIN categories c ON p.category_id = c.category_id WHERE 1=1 "
        );

        boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();
        boolean hasCategory = categoryId != null && categoryId > 0;

        if (hasKeyword) {
            sql.append("AND (p.product_name LIKE ? OR p.product_code LIKE ? OR p.barcode LIKE ?) ");
        }
        if (hasCategory) {
            sql.append("AND p.category_id = ? ");
        }
        sql.append("ORDER BY p.product_name ASC");

        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                int paramIndex = 1;
                if (hasKeyword) {
                    String pattern = "%" + keyword.trim() + "%";
                    stmt.setString(paramIndex++, pattern);
                    stmt.setString(paramIndex++, pattern);
                    stmt.setString(paramIndex++, pattern);
                }
                if (hasCategory) {
                    stmt.setInt(paramIndex++, categoryId);
                }

                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapProduct(rs));
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error searching products", ex);
        }
        return list;
    }

    public List<Product> getLowStockProducts() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.product_id, p.product_code, p.product_name, p.category_id, c.category_name, "
                   + "p.cost_price, p.selling_price, p.stock_quantity, p.reorder_level, p.barcode, p.created_at "
                   + "FROM products p "
                   + "LEFT JOIN categories c ON p.category_id = c.category_id "
                   + "WHERE p.stock_quantity <= p.reorder_level "
                   + "ORDER BY p.stock_quantity ASC";

        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapProduct(rs));
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error fetching low stock products", ex);
        }
        return list;
    }

    public boolean addProduct(Product product) {
        String sql = "INSERT INTO products (product_code, product_name, category_id, cost_price, selling_price, "
                   + "stock_quantity, reorder_level, barcode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, product.getProductCode());
                stmt.setString(2, product.getProductName());
                stmt.setInt(3, product.getCategoryId());
                stmt.setBigDecimal(4, product.getCostPrice());
                stmt.setBigDecimal(5, product.getSellingPrice());
                stmt.setInt(6, product.getStockQuantity());
                stmt.setInt(7, product.getReorderLevel());
                stmt.setString(8, product.getBarcode());

                int affected = stmt.executeUpdate();
                if (affected > 0) {
                    try (ResultSet keys = stmt.getGeneratedKeys()) {
                        if (keys.next()) {
                            product.setProductId(keys.getInt(1));
                        }
                    }
                    return true;
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error adding product: " + product.getProductName(), ex);
        }
        return false;
    }

    public boolean updateProduct(Product product) {
        String sql = "UPDATE products SET product_name = ?, category_id = ?, cost_price = ?, selling_price = ?, "
                   + "stock_quantity = ?, reorder_level = ?, barcode = ? WHERE product_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, product.getProductName());
                stmt.setInt(2, product.getCategoryId());
                stmt.setBigDecimal(3, product.getCostPrice());
                stmt.setBigDecimal(4, product.getSellingPrice());
                stmt.setInt(5, product.getStockQuantity());
                stmt.setInt(6, product.getReorderLevel());
                stmt.setString(7, product.getBarcode());
                stmt.setInt(8, product.getProductId());
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error updating product ID: " + product.getProductId(), ex);
        }
        return false;
    }

    public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, productId);
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error deleting product ID: " + productId, ex);
        }
        return false;
    }

    /**
     * Deducts stock as part of an ACID transaction.
     */
    public boolean deductStock(Connection conn, int productId, int quantity) throws SQLException {
        String sql = "UPDATE products SET stock_quantity = stock_quantity - ? "
                   + "WHERE product_id = ? AND stock_quantity >= ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, quantity);
            stmt.setInt(2, productId);
            stmt.setInt(3, quantity);
            return stmt.executeUpdate() > 0;
        }
    }

    public String generateNextProductCode() {
        String sql = "SELECT MAX(product_id) AS max_id FROM products";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int next = rs.getInt("max_id") + 1;
                    return String.format("PROD-%03d", next);
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.WARNING, "Error generating next product code", ex);
        }
        return "PROD-101";
    }

    private Product mapProduct(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setProductId(rs.getInt("product_id"));
        p.setProductCode(rs.getString("product_code"));
        p.setProductName(rs.getString("product_name"));
        p.setCategoryId(rs.getInt("category_id"));
        p.setCategoryName(rs.getString("category_name"));
        p.setCostPrice(rs.getBigDecimal("cost_price"));
        p.setSellingPrice(rs.getBigDecimal("selling_price"));
        p.setStockQuantity(rs.getInt("stock_quantity"));
        p.setReorderLevel(rs.getInt("reorder_level"));
        p.setBarcode(rs.getString("barcode"));
        p.setCreatedAt(rs.getTimestamp("created_at"));
        return p;
    }
}

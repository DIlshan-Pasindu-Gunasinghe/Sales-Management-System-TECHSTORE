package com.ead.sales.view;

import com.ead.sales.dao.DAOFactory;
import com.ead.sales.model.Order;
import com.ead.sales.model.OrderItem;
import com.ead.sales.service.ReportService;
import com.ead.sales.util.ExceptionHandler;
import com.ead.sales.util.UITheme;
import net.sf.jasperreports.engine.JasperPrint;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * OrderHistoryPanel: Sales Invoices & Transaction History
 * Allows auditing previous transactions, viewing itemized lines, and reprinting Jasper receipts.
 */
public class OrderHistoryPanel extends JPanel {

    private JTable tblOrders;
    private DefaultTableModel modelOrders;

    private JTable tblOrderItems;
    private DefaultTableModel modelOrderItems;

    private JLabel lblSelectedInvoice;
    private JLabel lblGrandTotal;
    private JButton btnViewReceipt;
    private JButton btnExportPdf;

    private Order selectedOrder;

    public OrderHistoryPanel() {
        initComponents();
        loadOrders();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UITheme.BG_LIGHT);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // Top Bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        JLabel lblTitle = new JLabel("Sales Transaction History & Invoices");
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(UITheme.TEXT_MAIN);

        JButton btnRefresh = UITheme.createOutlineButton("Refresh");
        btnRefresh.addActionListener(e -> loadOrders());

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(btnRefresh, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // Split Pane: Top/Left Orders Table, Bottom/Right Order Items
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setResizeWeight(0.55);
        splitPane.setDividerSize(6);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);

        // TOP: Orders Table Card
        JPanel cardOrders = UITheme.createCardPanel();
        cardOrders.setLayout(new BorderLayout(8, 8));

        JLabel lblListT = new JLabel("Completed Sales Orders");
        lblListT.setFont(UITheme.FONT_SUBTITLE);
        lblListT.setForeground(UITheme.TEXT_MAIN);
        cardOrders.add(lblListT, BorderLayout.NORTH);

        String[] orderCols = {"Order ID", "Invoice No", "Customer Name", "Phone", "Cashier", "Date & Time", "Payment", "Grand Total (Rs)", "Status"};
        modelOrders = new DefaultTableModel(orderCols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblOrders = new JTable(modelOrders);
        tblOrders.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblOrders, 0, SwingConstants.CENTER);
        alignTableColumn(tblOrders, 1, SwingConstants.CENTER);
        alignTableColumn(tblOrders, 6, SwingConstants.CENTER);
        alignTableColumn(tblOrders, 7, SwingConstants.RIGHT);
        alignTableColumn(tblOrders, 8, SwingConstants.CENTER);

        tblOrders.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tblOrders.getSelectedRow() != -1) {
                onOrderSelected();
            }
        });

        cardOrders.add(new JScrollPane(tblOrders), BorderLayout.CENTER);
        splitPane.setTopComponent(cardOrders);

        // BOTTOM: Selected Order Line Items & Actions Card
        JPanel cardItems = UITheme.createCardPanel();
        cardItems.setLayout(new BorderLayout(10, 10));

        JPanel itemsHeader = new JPanel(new BorderLayout());
        itemsHeader.setOpaque(false);

        lblSelectedInvoice = new JLabel("Select an invoice above to view line items");
        lblSelectedInvoice.setFont(UITheme.FONT_SUBTITLE);
        lblSelectedInvoice.setForeground(UITheme.PRIMARY);

        lblGrandTotal = new JLabel("");
        lblGrandTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblGrandTotal.setForeground(UITheme.PRIMARY_DARK);

        itemsHeader.add(lblSelectedInvoice, BorderLayout.WEST);
        itemsHeader.add(lblGrandTotal, BorderLayout.EAST);
        cardItems.add(itemsHeader, BorderLayout.NORTH);

        String[] itemCols = {"#", "Product Code", "Product Name", "Unit Cost", "Unit Sell Price", "Quantity", "Total Price (Rs)"};
        modelOrderItems = new DefaultTableModel(itemCols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblOrderItems = new JTable(modelOrderItems);
        tblOrderItems.setFont(UITheme.FONT_REGULAR);
        alignTableColumn(tblOrderItems, 0, SwingConstants.CENTER);
        alignTableColumn(tblOrderItems, 3, SwingConstants.RIGHT);
        alignTableColumn(tblOrderItems, 4, SwingConstants.RIGHT);
        alignTableColumn(tblOrderItems, 5, SwingConstants.CENTER);
        alignTableColumn(tblOrderItems, 6, SwingConstants.RIGHT);

        cardItems.add(new JScrollPane(tblOrderItems), BorderLayout.CENTER);

        // Footer Action Buttons
        JPanel footerActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 5));
        footerActions.setOpaque(false);

        btnViewReceipt = UITheme.createPrimaryButton("Preview Jasper Receipt");
        btnViewReceipt.setEnabled(false);
        btnViewReceipt.addActionListener(e -> viewReceiptReport());

        btnExportPdf = UITheme.createSuccessButton("Export Invoice to PDF");
        btnExportPdf.setEnabled(false);
        btnExportPdf.addActionListener(e -> exportReceiptToPdf());

        footerActions.add(btnViewReceipt);
        footerActions.add(btnExportPdf);
        cardItems.add(footerActions, BorderLayout.SOUTH);

        splitPane.setBottomComponent(cardItems);
        add(splitPane, BorderLayout.CENTER);
    }

    public void loadOrders() {
        List<Order> list = DAOFactory.getInstance().getOrderDAO().getAllOrders();
        modelOrders.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        for (Order o : list) {
            modelOrders.addRow(new Object[]{
                    o.getOrderId(),
                    o.getInvoiceNo(),
                    o.getCustomerName(),
                    o.getCustomerPhone(),
                    o.getCashierName(),
                    o.getOrderDate() != null ? sdf.format(o.getOrderDate()) : "-",
                    o.getPaymentMethod(),
                    String.format("%,.2f", o.getGrandTotal()),
                    o.getStatus()
            });
        }
        clearDetailSelection();
    }

    private void onOrderSelected() {
        int row = tblOrders.getSelectedRow();
        if (row != -1) {
            int orderId = (int) modelOrders.getValueAt(row, 0);
            selectedOrder = DAOFactory.getInstance().getOrderDAO().getOrderById(orderId);
            if (selectedOrder != null) {
                lblSelectedInvoice.setText("Order Items for " + selectedOrder.getInvoiceNo() 
                        + " | Customer: " + selectedOrder.getCustomerName());
                lblGrandTotal.setText("Grand Total: Rs. " + String.format("%,.2f", selectedOrder.getGrandTotal()));

                modelOrderItems.setRowCount(0);
                int index = 1;
                for (OrderItem item : selectedOrder.getItems()) {
                    modelOrderItems.addRow(new Object[]{
                            index++,
                            item.getProductCode(),
                            item.getProductName(),
                            String.format("%,.2f", item.getUnitCostPrice()),
                            String.format("%,.2f", item.getUnitSellingPrice()),
                            item.getQuantity(),
                            String.format("%,.2f", item.getTotalPrice())
                    });
                }

                btnViewReceipt.setEnabled(true);
                btnExportPdf.setEnabled(true);
            }
        }
    }

    private void viewReceiptReport() {
        if (selectedOrder == null) return;
        try {
            JasperPrint print = ReportService.getInstance().generateReceipt(selectedOrder.getOrderId());
            ReportService.getInstance().viewReport(print, "Tax Invoice Receipt: " + selectedOrder.getInvoiceNo());
        } catch (Exception ex) {
            ExceptionHandler.showError(this, "Failed to preview receipt: " + ex.getMessage());
        }
    }

    private void exportReceiptToPdf() {
        if (selectedOrder == null) return;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new File(selectedOrder.getInvoiceNo() + ".pdf"));
        int option = fileChooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File targetFile = fileChooser.getSelectedFile();
            try {
                JasperPrint print = ReportService.getInstance().generateReceipt(selectedOrder.getOrderId());
                ReportService.getInstance().exportToPdf(print, targetFile);
                ExceptionHandler.showSuccess(this, "Invoice PDF saved successfully to:\n" + targetFile.getAbsolutePath());
            } catch (Exception ex) {
                ExceptionHandler.showError(this, "Failed to export PDF: " + ex.getMessage());
            }
        }
    }

    private void clearDetailSelection() {
        selectedOrder = null;
        lblSelectedInvoice.setText("Select an invoice above to view line items");
        lblGrandTotal.setText("");
        modelOrderItems.setRowCount(0);
        btnViewReceipt.setEnabled(false);
        btnExportPdf.setEnabled(false);
    }

    private void alignTableColumn(JTable table, int colIndex, int alignment) {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(alignment);
        table.getColumnModel().getColumn(colIndex).setCellRenderer(renderer);
    }
}

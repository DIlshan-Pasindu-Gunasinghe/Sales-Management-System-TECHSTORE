package com.ead.sales.service;

import com.ead.sales.dao.DAOFactory;
import com.ead.sales.dao.OrderDAO;
import com.ead.sales.dao.ProductDAO;
import com.ead.sales.model.DashboardSummary;
import com.ead.sales.model.Order;
import com.ead.sales.model.OrderItem;
import com.ead.sales.model.Product;
import com.ead.sales.util.ValidationException;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/**
 * Service Pattern: SalesService
 * Coordinates sales transactions, inventory validation, and order management.
 */
public class SalesService {

    private final OrderDAO orderDAO = DAOFactory.getInstance().getOrderDAO();
    private final ProductDAO productDAO = DAOFactory.getInstance().getProductDAO();

    public boolean completeSale(Order order) throws ValidationException, SQLException {
        if (order.getItems().isEmpty()) {
            throw new ValidationException("Cannot checkout: Cart is empty! Add at least one item.");
        }
        if (order.getCustomerId() <= 0) {
            throw new ValidationException("Please select a customer for this transaction.");
        }
        if (order.getGrandTotal().compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException("Grand total cannot be negative.");
        }

        // Validate payment
        ValidationService.validatePayment(order.getAmountPaid(), order.getGrandTotal());

        // Recheck real-time inventory levels before finalizing
        for (OrderItem item : order.getItems()) {
            Product currentProduct = productDAO.getProductById(item.getProductId());
            if (currentProduct == null) {
                throw new ValidationException("Product not found: " + item.getProductName());
            }
            if (currentProduct.getStockQuantity() < item.getQuantity()) {
                throw new ValidationException("Insufficient stock for '" + currentProduct.getProductName()
                        + "'. Available: " + currentProduct.getStockQuantity() + ", Requested: " + item.getQuantity());
            }
        }

        return orderDAO.processSaleTransaction(order);
    }

    public List<Order> getAllOrders() {
        return orderDAO.getAllOrders();
    }

    public Order getOrderById(int orderId) {
        return orderDAO.getOrderById(orderId);
    }

    public DashboardSummary getDashboardSummary() {
        return orderDAO.getDashboardSummary();
    }

    public String generateNextInvoiceNo() {
        return orderDAO.generateNextInvoiceNo();
    }
}

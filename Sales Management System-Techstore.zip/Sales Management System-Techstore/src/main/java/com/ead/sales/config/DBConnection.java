package com.ead.sales.config;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Singleton Pattern: DBConnection
 * Provides a single, globally accessible database connection instance
 * for the entire application.
 */
public class DBConnection {

    private static final Logger LOGGER = Logger.getLogger(DBConnection.class.getName());
    private static DBConnection instance;
    private Connection connection;

    private String dbHost = "localhost";
    private String dbPort = "3306";
    private String dbName = "ead_sales_db";
    private String dbUser = "root";
    private String dbPass = "osl20031975@0210";
    private String dbUrl;

    /**
     * Private constructor to enforce Singleton design pattern.
     */
    private DBConnection() {
        loadProperties();
        connect();
    }

    private void loadProperties() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("database.properties")) {
            Properties prop = new Properties();
            if (input != null) {
                prop.load(input);
                dbHost = prop.getProperty("db.host", dbHost);
                dbPort = prop.getProperty("db.port", dbPort);
                dbName = prop.getProperty("db.name", dbName);
                dbUser = prop.getProperty("db.username", dbUser);
                dbPass = prop.getProperty("db.password", dbPass);
                dbUrl = prop.getProperty("db.url");
            }
        } catch (Exception ex) {
            LOGGER.log(Level.WARNING, "Failed to load database.properties, using default credentials.", ex);
        }

        if (dbUrl == null || dbUrl.isEmpty()) {
            dbUrl = "jdbc:mysql://" + dbHost + ":" + dbPort + "/" + dbName
                    + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
        }
    }

    private void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            LOGGER.info("Successfully connected to MySQL database: " + dbName);
        } catch (ClassNotFoundException ex) {
            LOGGER.log(Level.SEVERE, "MySQL JDBC Driver not found in classpath!", ex);
        } catch (SQLException ex) {
            LOGGER.log(Level.WARNING, "Direct database connection failed, attempting auto-setup: " + ex.getMessage());
            // Attempt to connect to MySQL server root and ensure database exists
            if (tryInitializeDatabase()) {
                try {
                    this.connection = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                    LOGGER.info("Connected after database creation.");
                } catch (SQLException e) {
                    LOGGER.log(Level.SEVERE, "Could not establish database connection after setup attempt", e);
                }
            }
        }
    }

    private boolean tryInitializeDatabase() {
        String serverUrl = "jdbc:mysql://" + dbHost + ":" + dbPort
                + "/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        try (Connection serverConn = DriverManager.getConnection(serverUrl, dbUser, dbPass);
             Statement stmt = serverConn.createStatement()) {

            LOGGER.info("Creating database " + dbName + " if not exists...");
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + dbName + "` "
                    + "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");

            return true;
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Could not initialize database on MySQL server: " + ex.getMessage());
            return false;
        }
    }

    /**
     * Singleton accessor method.
     * Synchronized to guarantee thread safety in multi-threaded environments.
     */
    public static synchronized DBConnection getInstance() {
        if (instance == null) {
            instance = new DBConnection();
        }
        return instance;
    }

    /**
     * Returns an active SQL connection.
     * Reopens connection automatically if it timed out or was closed.
     */
    public synchronized Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed() || !connection.isValid(2)) {
            LOGGER.info("Database connection lost or stale, reconnecting...");
            connect();
        }
        return connection;
    }

    /**
     * Closes the connection gracefully upon application exit.
     */
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                LOGGER.info("Database connection closed gracefully.");
            } catch (SQLException ex) {
                LOGGER.log(Level.WARNING, "Error closing database connection", ex);
            }
        }
    }
}

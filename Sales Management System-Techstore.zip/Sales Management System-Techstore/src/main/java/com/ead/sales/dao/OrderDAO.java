package com.ead.sales.dao;

import com.ead.sales.config.DBConnection;
import com.ead.sales.model.DashboardSummary;
import com.ead.sales.model.Order;
import com.ead.sales.model.OrderItem;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DAO Pattern: OrderDAO
 * Manages Sales Order transactions and Executive Dashboard analytics.
 */
public class OrderDAO {

    private static final Logger LOGGER = Logger.getLogger(OrderDAO.class.getName());
    private final ProductDAO productDAO = new ProductDAO();

    /**
     * Executes a complete Sales Transaction with ACID compliance.
     * Atomically saves the Order, inserts Order Items, and decrements Inventory Stock.
     */
    public boolean processSaleTransaction(Order order) throws SQLException {
        Connection conn = null;
        boolean originalAutoCommit = true;

        String insertOrderSql = "INSERT INTO orders (invoice_no, customer_id, user_id, order_date, subtotal, "
                + "discount_amount, tax_amount, grand_total, payment_method, amount_paid, balance_returned, status, notes) "
                + "VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        String insertItemSql = "INSERT INTO order_items (order_id, product_id, unit_cost_price, unit_selling_price, "
                + "quantity, total_price) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            conn = DBConnection.getInstance().getConnection();
            originalAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false); // Begin ACID Transaction

            int orderId;
            try (PreparedStatement orderStmt = conn.prepareStatement(insertOrderSql, Statement.RETURN_GENERATED_KEYS)) {
                orderStmt.setString(1, order.getInvoiceNo());
                orderStmt.setInt(2, order.getCustomerId());
                orderStmt.setInt(3, order.getUserId());
                orderStmt.setBigDecimal(4, order.getSubtotal());
                orderStmt.setBigDecimal(5, order.getDiscountAmount());
                orderStmt.setBigDecimal(6, order.getTaxAmount());
                orderStmt.setBigDecimal(7, order.getGrandTotal());
                orderStmt.setString(8, order.getPaymentMethod());
                orderStmt.setBigDecimal(9, order.getAmountPaid());
                orderStmt.setBigDecimal(10, order.getBalanceReturned());
                orderStmt.setString(11, order.getStatus() != null ? order.getStatus() : "COMPLETED");
                orderStmt.setString(12, order.getNotes());

                int affected = orderStmt.executeUpdate();
                if (affected == 0) {
                    throw new SQLException("Failed to create sales order header.");
                }

                try (ResultSet generatedKeys = orderStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        orderId = generatedKeys.getInt(1);
                        order.setOrderId(orderId);
                    } else {
                        throw new SQLException("Failed to obtain generated Order ID.");
                    }
                }
            }

            // Insert Line Items & Deduct Stock
            try (PreparedStatement itemStmt = conn.prepareStatement(insertItemSql)) {
                for (OrderItem item : order.getItems()) {
                    item.setOrderId(orderId);
                    itemStmt.setInt(1, orderId);
                    itemStmt.setInt(2, item.getProductId());
                    itemStmt.setBigDecimal(3, item.getUnitCostPrice());
                    itemStmt.setBigDecimal(4, item.getUnitSellingPrice());
                    itemStmt.setInt(5, item.getQuantity());
                    itemStmt.setBigDecimal(6, item.getTotalPrice());
                    itemStmt.addBatch();

                    // Deduct stock within same transaction
                    boolean stockUpdated = productDAO.deductStock(conn, item.getProductId(), item.getQuantity());
                    if (!stockUpdated) {
                        throw new SQLException("Insufficient stock available for Product: " + item.getProductName());
                    }
                }
                itemStmt.executeBatch();
            }

            // Commit Transaction
            conn.commit();
            LOGGER.info("Transaction successfully committed for Invoice: " + order.getInvoiceNo());
            return true;

        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Transaction failed! Rolling back changes for Invoice: " + order.getInvoiceNo(), ex);
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rbEx) {
                    LOGGER.log(Level.SEVERE, "Rollback failed", rbEx);
                }
            }
            throw ex;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                } catch (SQLException ex) {
                    LOGGER.log(Level.WARNING, "Failed to reset autocommit", ex);
                }
            }
        }
    }

    public List<Order> getAllOrders() {
        List<Order> list = new ArrayList<>();
        String sql = "SELECT o.order_id, o.invoice_no, o.customer_id, c.name AS customer_name, c.phone AS customer_phone, "
                   + "o.user_id, u.full_name AS cashier_name, o.order_date, o.subtotal, o.discount_amount, o.tax_amount, "
                   + "o.grand_total, o.payment_method, o.amount_paid, o.balance_returned, o.status, o.notes "
                   + "FROM orders o "
                   + "JOIN customers c ON o.customer_id = c.customer_id "
                   + "JOIN users u ON o.user_id = u.user_id "
                   + "ORDER BY o.order_date DESC";

        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapOrder(rs));
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving all orders", ex);
        }
        return list;
    }

    public Order getOrderById(int orderId) {
        String sql = "SELECT o.order_id, o.invoice_no, o.customer_id, c.name AS customer_name, c.phone AS customer_phone, "
                   + "o.user_id, u.full_name AS cashier_name, o.order_date, o.subtotal, o.discount_amount, o.tax_amount, "
                   + "o.grand_total, o.payment_method, o.amount_paid, o.balance_returned, o.status, o.notes "
                   + "FROM orders o "
                   + "JOIN customers c ON o.customer_id = c.customer_id "
                   + "JOIN users u ON o.user_id = u.user_id "
                   + "WHERE o.order_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, orderId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        Order o = mapOrder(rs);
                        o.setItems(getOrderItems(orderId));
                        return o;
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving order ID: " + orderId, ex);
        }
        return null;
    }

    public List<OrderItem> getOrderItems(int orderId) {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT oi.order_item_id, oi.order_id, oi.product_id, p.product_code, p.product_name, "
                   + "oi.unit_cost_price, oi.unit_selling_price, oi.quantity, oi.total_price "
                   + "FROM order_items oi "
                   + "JOIN products p ON oi.product_id = p.product_id "
                   + "WHERE oi.order_id = ?";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, orderId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        OrderItem item = new OrderItem();
                        item.setOrderItemId(rs.getInt("order_item_id"));
                        item.setOrderId(rs.getInt("order_id"));
                        item.setProductId(rs.getInt("product_id"));
                        item.setProductCode(rs.getString("product_code"));
                        item.setProductName(rs.getString("product_name"));
                        item.setUnitCostPrice(rs.getBigDecimal("unit_cost_price"));
                        item.setUnitSellingPrice(rs.getBigDecimal("unit_selling_price"));
                        item.setQuantity(rs.getInt("quantity"));
                        item.setTotalPrice(rs.getBigDecimal("total_price"));
                        items.add(item);
                    }
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving order items for order ID: " + orderId, ex);
        }
        return items;
    }

    public DashboardSummary getDashboardSummary() {
        DashboardSummary summary = new DashboardSummary();
        try {
            Connection conn = DBConnection.getInstance().getConnection();

            // 1. Today Revenue and Count
            String todaySql = "SELECT COALESCE(SUM(grand_total), 0) AS today_rev, COUNT(*) AS today_count "
                            + "FROM orders WHERE DATE(order_date) = CURDATE() AND status = 'COMPLETED'";
            try (PreparedStatement stmt = conn.prepareStatement(todaySql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    summary.setTodayRevenue(rs.getBigDecimal("today_rev"));
                    summary.setTodayOrderCount(rs.getInt("today_count"));
                }
            }

            // 2. Month Revenue and Count
            String monthSql = "SELECT COALESCE(SUM(grand_total), 0) AS month_rev, COUNT(*) AS month_count "
                            + "FROM orders WHERE MONTH(order_date) = MONTH(CURDATE()) "
                            + "AND YEAR(order_date) = YEAR(CURDATE()) AND status = 'COMPLETED'";
            try (PreparedStatement stmt = conn.prepareStatement(monthSql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    summary.setMonthRevenue(rs.getBigDecimal("month_rev"));
                    summary.setMonthOrderCount(rs.getInt("month_count"));
                }
            }

            // 3. Total Products & Low Stock count
            String prodSql = "SELECT COUNT(*) AS total_prods, "
                           + "SUM(CASE WHEN stock_quantity <= reorder_level THEN 1 ELSE 0 END) AS low_stock "
                           + "FROM products";
            try (PreparedStatement stmt = conn.prepareStatement(prodSql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    summary.setTotalProducts(rs.getInt("total_prods"));
                    summary.setLowStockCount(rs.getInt("low_stock"));
                }
            }

            // 4. Total Customers
            String custSql = "SELECT COUNT(*) AS total_custs FROM customers";
            try (PreparedStatement stmt = conn.prepareStatement(custSql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    summary.setTotalCustomers(rs.getInt("total_custs"));
                }
            }

            // 5. Recent 5 Orders
            String recentSql = "SELECT o.order_id, o.invoice_no, o.customer_id, c.name AS customer_name, c.phone AS customer_phone, "
                             + "o.user_id, u.full_name AS cashier_name, o.order_date, o.subtotal, o.discount_amount, o.tax_amount, "
                             + "o.grand_total, o.payment_method, o.amount_paid, o.balance_returned, o.status, o.notes "
                             + "FROM orders o "
                             + "JOIN customers c ON o.customer_id = c.customer_id "
                             + "JOIN users u ON o.user_id = u.user_id "
                             + "ORDER BY o.order_date DESC LIMIT 5";
            List<Order> recentList = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(recentSql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    recentList.add(mapOrder(rs));
                }
            }
            summary.setRecentOrders(recentList);

            // 6. Low stock products list
            summary.setLowStockProducts(productDAO.getLowStockProducts());

        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error building dashboard summary metrics", ex);
        }
        return summary;
    }

    public String generateNextInvoiceNo() {
        String year = new SimpleDateFormat("yyyy").format(new Date());
        String sql = "SELECT MAX(order_id) AS max_id FROM orders";
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int next = rs.getInt("max_id") + 1;
                    return String.format("INV-%s-%04d", year, next);
                }
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.WARNING, "Error generating next invoice number", ex);
        }
        return String.format("INV-%s-0001", year);
    }

    private Order mapOrder(ResultSet rs) throws SQLException {
        Order o = new Order();
        o.setOrderId(rs.getInt("order_id"));
        o.setInvoiceNo(rs.getString("invoice_no"));
        o.setCustomerId(rs.getInt("customer_id"));
        o.setCustomerName(rs.getString("customer_name"));
        o.setCustomerPhone(rs.getString("customer_phone"));
        o.setUserId(rs.getInt("user_id"));
        o.setCashierName(rs.getString("cashier_name"));
        o.setOrderDate(rs.getTimestamp("order_date"));
        o.setSubtotal(rs.getBigDecimal("subtotal"));
        o.setDiscountAmount(rs.getBigDecimal("discount_amount"));
        o.setTaxAmount(rs.getBigDecimal("tax_amount"));
        o.setGrandTotal(rs.getBigDecimal("grand_total"));
        o.setPaymentMethod(rs.getString("payment_method"));
        o.setAmountPaid(rs.getBigDecimal("amount_paid"));
        o.setBalanceReturned(rs.getBigDecimal("balance_returned"));
        o.setStatus(rs.getString("status"));
        o.setNotes(rs.getString("notes"));
        return o;
    }
}
